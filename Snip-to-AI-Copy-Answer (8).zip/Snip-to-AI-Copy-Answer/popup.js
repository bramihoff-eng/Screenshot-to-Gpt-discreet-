const chats=document.getElementById('chats'), status=document.getElementById('status'), capture=document.getElementById('capture');
let destinations=[];
async function loadChats(){
 status.textContent='Loading your chats…';
 const {savedDestination, latestAnswer}=await chrome.storage.local.get(['savedDestination','latestAnswer']);
 document.getElementById('answer').textContent=latestAnswer?.answer || 'No reply received yet.';
 capture.disabled=!savedDestination;
 let response;
 try {response=await chrome.runtime.sendMessage({type:'GET_RECENT_CHATS',provider:'chatgpt',limit:20});} catch(e){response={chats:[]};}
 destinations=(response?.chats || []).map(c=>({targetTabId:c.tabId,targetChatUrl:c.url,label:c.title || c.name || c.url || 'ChatGPT chat'}));
 if(savedDestination && !destinations.some(d=>d.targetChatUrl===savedDestination.targetChatUrl)) destinations.unshift(savedDestination);
 chats.replaceChildren(new Option('Choose a chat once…',''));
 destinations.forEach((d,i)=>chats.add(new Option(d.label || d.targetChatUrl,String(i))));
 if(savedDestination){const i=destinations.findIndex(d=>d.targetChatUrl===savedDestination.targetChatUrl);if(i>=0)chats.value=String(i);}
 status.textContent=savedDestination ? 'Saved chat: '+(savedDestination.label || savedDestination.targetChatUrl) : 'Select a chat or paste its link.';
}
chats.addEventListener('change',async()=>{
 if(chats.value==='')return;
 const savedDestination=destinations[Number(chats.value)];
 await chrome.storage.local.set({savedDestination});capture.disabled=false;status.textContent='Chat saved. Future screenshots use this chat.';
});
document.getElementById('saveUrl').addEventListener('click',async()=>{
 try{
  const url=new URL(document.getElementById('url').value.trim());
  if(!['chatgpt.com','chat.openai.com'].includes(url.hostname)||url.protocol!=='https:'||!url.pathname.includes('/c/'))throw Error('Paste the full link to a ChatGPT conversation.');
  await chrome.storage.local.set({savedDestination:{targetChatUrl:url.href,label:'Saved ChatGPT conversation'}});await loadChats();
 }catch(e){status.textContent=e.message;}
});
capture.addEventListener('click',()=>{
 chrome.runtime.sendMessage({type:'START_CAPTURE_FROM_POPUP',mode:'quick'}).catch(()=>{});window.close();
});
document.getElementById('refresh').addEventListener('click',loadChats);
chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes.latestAnswer)document.getElementById('answer').textContent=changes.latestAnswer.newValue?.answer || '';});
void loadChats();
