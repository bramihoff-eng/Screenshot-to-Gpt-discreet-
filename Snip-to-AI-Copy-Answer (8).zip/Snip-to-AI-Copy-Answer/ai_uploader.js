(() => {
  const UPLOADER_SCRIPT_VERSION = "2026-09-28-r9";

  if (window.__snipToAiUploaderVersion === UPLOADER_SCRIPT_VERSION) {
    return;
  }

  if (typeof window.__snipToAiUploaderDispose === "function") {
    try {
      window.__snipToAiUploaderDispose();
    } catch (_error) {
      // Best-effort cleanup when replacing an older uploader script.
    }
  }

  window.__snipToAiUploaderLoaded = true;
  window.__snipToAiUploaderVersion = UPLOADER_SCRIPT_VERSION;

  const GENERIC_SELECTORS = [
    'input[type="file"][accept*="image"]',
    'input[type="file"][aria-label*="upload" i]',
    'input[type="file"]'
  ];
  const PROMPT_INPUT_SELECTORS = [
    'textarea:not([disabled])',
    'div[contenteditable="true"][role="textbox"]',
    'div[contenteditable="true"]'
  ];
  const SEND_BUTTON_SELECTORS = [
    'button[data-testid*="send" i]:not([disabled])',
    'button[aria-label*="send" i]:not([disabled])',
    'button[title*="send" i]:not([disabled])',
    'button[type="submit"]:not([disabled])'
  ];
  const PROMPT_READY_TIMEOUT_MS = 6000;
  const SEND_READY_TIMEOUT_MS = 7000;
  const SEND_STABLE_CHECKS = 3;
  const UPLOAD_ACCEPTANCE_SETTLE_MS = 650;

  function onRuntimeMessage(message, _sender, sendResponse) {
    if (message?.type !== "AI_UPLOAD_IMAGE") {
      return false;
    }

    uploadImage(message)
      .then((result) => sendResponse({ ok: result.code === "DELIVERED", ...result }))
      .catch((error) => sendResponse({
        ok: false,
        code: "UPLOAD_DISPATCH_FAILED",
        message: error.message || "Could not upload image to AI tab."
      }));

    return true;
  }

  chrome.runtime.onMessage.addListener(onRuntimeMessage);

  window.__snipToAiUploaderDispose = () => {
    chrome.runtime.onMessage.removeListener(onRuntimeMessage);
  };

  async function uploadImage(payload) {
    const providerLabel = String(payload?.providerLabel || "AI");

    if (!payload?.imageDataUrl) {
      return {
        code: "UPLOAD_DISPATCH_FAILED",
        message: "Missing image payload."
      };
    }

    let file;
    try {
      file = await dataUrlToFile(payload.imageDataUrl);
    } catch (_error) {
      return {
        code: "UPLOAD_DISPATCH_FAILED",
        message: "Could not decode image payload."
      };
    }

    const selectors = dedupe([
      ...(Array.isArray(payload.preferredSelectors) ? payload.preferredSelectors : []),
      ...GENERIC_SELECTORS
    ]);

    const waitTimeoutMs = normalizeTimeout(payload?.waitTimeoutMs, 5000, 1000, 30000);
    const fileInput = await waitForFileInput(selectors, waitTimeoutMs);
    if (!fileInput) {
      return {
        code: "UPLOAD_INPUT_NOT_FOUND",
        message: `No compatible upload input found on ${providerLabel}.`
      };
    }

    const firstAttempt = dispatchImageToInput(fileInput, file);
    if (firstAttempt.ok) {
      return finishDeliveredUpload(payload, providerLabel);
    }

    await delay(250);

    const retryInput = await waitForFileInput(selectors, 1500);
    if (!retryInput) {
      return {
        code: "UPLOAD_INPUT_NOT_FOUND",
        message: "Upload input disappeared before retry."
      };
    }

    const retryAttempt = dispatchImageToInput(retryInput, file);
    if (!retryAttempt.ok) {
      return {
        code: "UPLOAD_DISPATCH_FAILED",
        message: retryAttempt.message || firstAttempt.message || `Upload failed in ${providerLabel} tab.`
      };
    }

    return finishDeliveredUpload(payload, providerLabel);
  }

  async function finishDeliveredUpload(payload, providerLabel) {
    await delay(UPLOAD_ACCEPTANCE_SETTLE_MS);
    const textResult = await attachPromptTextAndSend(payload?.promptText, payload);
    if (payload?.watchAnswer && textResult.textSent !== true) {
      return {
        code: "UPLOAD_DISPATCH_FAILED",
        message: textResult.message || "Could not send the screenshot to ChatGPT.",
        textRequested: true,
        textSent: false
      };
    }
    return {
      code: "DELIVERED",
      message: textResult.message || `Image uploaded to ${providerLabel}.`,
      textRequested: textResult.textRequested,
      textSent: textResult.textSent
    };
  }

  async function dataUrlToFile(dataUrl) {
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    return new File([blob], `snip-${Date.now()}.png`, { type: blob.type || "image/png" });
  }

  function findImageFileInput(selectors) {
    for (const selector of selectors) {
      const matches = Array.from(document.querySelectorAll(selector));
      const filtered = matches.filter(isImageCompatibleInput);
      const visible = filtered.find(isVisible);
      if (visible) {
        return visible;
      }
      if (filtered[0]) {
        return filtered[0];
      }
    }

    const fallbackInputs = Array.from(document.querySelectorAll('input[type="file"]')).filter(isImageCompatibleInput);
    return fallbackInputs.find(isVisible) || fallbackInputs[0] || null;
  }

  function dispatchImageToInput(fileInput, file) {
    if (!fileInput || fileInput.hasAttribute("disabled")) {
      return {
        ok: false,
        message: "Upload input is unavailable."
      };
    }

    try {
      const transfer = new DataTransfer();
      transfer.items.add(file);
      fileInput.files = transfer.files;
      const acceptedBeforeEvents = Boolean(fileInput.files && fileInput.files.length > 0);
      fileInput.dispatchEvent(new Event("input", { bubbles: true }));
      fileInput.dispatchEvent(new Event("change", { bubbles: true }));

      if (!acceptedBeforeEvents && (!fileInput.files || fileInput.files.length < 1)) {
        return {
          ok: false,
          message: "Upload input did not accept the selected file."
        };
      }

      return {
        ok: true
      };
    } catch (_error) {
      return {
        ok: false,
        message: "Upload input exists but could not receive the image."
      };
    }
  }

  function waitForFileInput(selectors, timeoutMs) {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      let settled = false;
      let observer = null;
      let pollTimer = null;
      let timeoutTimer = null;

      const done = (result) => {
        if (settled) {
          return;
        }
        settled = true;
        if (observer) {
          observer.disconnect();
        }
        if (pollTimer) {
          clearInterval(pollTimer);
        }
        if (timeoutTimer) {
          clearTimeout(timeoutTimer);
        }
        resolve(result || null);
      };

      const checkNow = () => {
        const input = findImageFileInput(selectors);
        if (input) {
          done(input);
          return true;
        }

        if (Date.now() - startedAt >= timeoutMs) {
          done(null);
          return true;
        }

        return false;
      };

      if (checkNow()) {
        return;
      }

      pollTimer = setInterval(checkNow, 120);
      const root = document.documentElement;
      if (root) {
        observer = new MutationObserver(() => {
          checkNow();
        });
        observer.observe(root, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ["style", "class", "hidden", "disabled", "aria-hidden"]
        });
      }

      timeoutTimer = setTimeout(() => done(null), timeoutMs + 80);
    });
  }

  function normalizeTimeout(rawValue, fallback, min, max) {
    const parsed = Number(rawValue);
    if (!Number.isFinite(parsed)) {
      return fallback;
    }
    return Math.min(max, Math.max(min, Math.floor(parsed)));
  }

  function delay(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function isImageCompatibleInput(input) {
    if (input.hasAttribute("disabled")) {
      return false;
    }

    const accept = (input.getAttribute("accept") || "").toLowerCase();
    if (!accept) {
      return true;
    }

    return accept.includes("image") || accept.includes("png") || accept.includes("jpg") || accept.includes("jpeg") || accept.includes("*");
  }

  function isVisible(el) {
    const style = window.getComputedStyle(el);
    const rect = el.getBoundingClientRect();
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      parseFloat(style.opacity || "1") > 0 &&
      rect.width > 0 &&
      rect.height > 0
    );
  }

  function dedupe(list) {
    return Array.from(new Set(list.filter(Boolean)));
  }

  async function attachPromptTextAndSend(rawPromptText, payload) {
    const promptText = String(rawPromptText || "").trim();
    if (!promptText) {
      return {
        ok: true,
        textRequested: false,
        textSent: null,
        message: ""
      };
    }

    await delay(350);
    const input = await waitForPromptInput(PROMPT_READY_TIMEOUT_MS);
    if (!input) {
      return {
        ok: true,
        textRequested: true,
        textSent: false,
        message: "Image attached, text not sent automatically."
      };
    }

    const inserted = setPromptValue(input, promptText);
    if (!inserted) {
      return {
        ok: true,
        textRequested: true,
        textSent: false,
        message: "Image attached, text not sent automatically."
      };
    }

    const sendButton = await waitForReadySendButton(input, SEND_READY_TIMEOUT_MS);
    if (!sendButton) {
      return {
        ok: true,
        textRequested: true,
        textSent: false,
        message: "Image attached, text inserted, but not sent automatically."
      };
    }

    const baseline = getLastAssistantAnswer();
    sendButton.click();
    // Reply retrieval is polled from the source tab through the extension worker.
    return {
      ok: true,
      textRequested: true,
      textSent: true,
      message: "Image + text sent."
    };
  }

  function getLastAssistantAnswer() {
    let turns = Array.from(document.querySelectorAll('[data-message-author-role="assistant"]'));
    if (!turns.length) turns = Array.from(document.querySelectorAll('[data-turn="assistant"], [data-role="assistant"], [data-testid="assistant-message"]'));
    if (!turns.length) turns = Array.from(document.querySelectorAll('article[data-testid^="conversation-turn-"]')).filter(node =>
      !node.querySelector('[data-message-author-role="user"]') && node.querySelector('[data-testid="copy-turn-action-button"]'));

    const turn = turns[turns.length - 1];
    if (!turn) return { count: 0, text: "" };
    const markdown = Array.from(turn.querySelectorAll(".markdown"));
    const text = markdown.length
      ? markdown.map((node) => node.innerText || node.textContent || "").join("\n\n")
      : turn.innerText || turn.textContent || "";
    return { count: turns.length, text: String(text).trim() };
  }

  async function watchForCompletedAnswer(baseline, payload) {
    const started = Date.now();
    let lastText = "";
    let stableSince = 0;
    while (Date.now() - started < 300000) {
      await delay(700);
      const current = getLastAssistantAnswer();
      const isNew = current.count > baseline.count || current.text !== baseline.text;
      if (!isNew || !current.text) continue;
      if (current.text !== lastText) {
        lastText = current.text;
        stableSince = Date.now();
        await chrome.runtime.sendMessage({ type: "ANSWER_UPDATE", answer: current.text, sourceTabId: payload.sourceTabId });
        continue;
      }
      const stillGenerating = Array.from(document.querySelectorAll(
        'button[data-testid="stop-button"], button[aria-label*="stop generating" i], button[aria-label*="stop streaming" i]'
      )).some(node => isVisible(node) && !node.disabled);
      if (stillGenerating || Date.now() - stableSince < 4000) continue;
      const result = await chrome.runtime.sendMessage({
        type: "ANSWER_COMPLETE",
        answer: current.text,
        sourceTabId: payload.sourceTabId,
        closeAfterAnswer: payload.closeAfterAnswer
      });
      if (!result?.ok) throw new Error(result?.message || "Could not deliver the reply to the answer panel.");
      return;
    }
    await chrome.runtime.sendMessage({
      type: "ANSWER_TIMEOUT",
      sourceTabId: payload.sourceTabId,
      closeAfterAnswer: payload.closeAfterAnswer
    });
  }

  function findPromptInput() {
    for (const selector of PROMPT_INPUT_SELECTORS) {
      const nodes = Array.from(document.querySelectorAll(selector));
      const visible = nodes.filter(isVisible);
      if (visible.length < 1) {
        continue;
      }
      visible.sort((a, b) => areaOf(b) - areaOf(a));
      return visible[0];
    }
    return null;
  }

  function setPromptValue(input, text) {
    try {
      input.focus();
      if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) {
        const valueSetter = input instanceof HTMLTextAreaElement
          ? Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, "value")?.set
          : Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
        if (valueSetter) {
          valueSetter.call(input, text);
        } else {
          input.value = text;
        }
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      }

      if (input instanceof HTMLElement && input.isContentEditable) {
        input.textContent = text;
        input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
        return true;
      }
    } catch (_error) {
      return false;
    }
    return false;
  }

  function findReadySendButton(input) {
    for (const root of getSendSearchRoots(input)) {
      for (const selector of SEND_BUTTON_SELECTORS) {
        const candidates = Array.from(root.querySelectorAll(selector))
          .filter((button) => isVisible(button) && isButtonEnabled(button));
        if (!candidates.length) {
          continue;
        }
        const button = candidates[0];
        if (button instanceof HTMLElement) {
          return button;
        }
      }
    }
    return null;
  }

  async function waitForPromptInput(timeoutMs) {
    return waitForResult(() => findPromptInput(), timeoutMs);
  }

  async function waitForReadySendButton(input, timeoutMs) {
    let stableCount = 0;
    return waitForResult(() => {
      const button = findReadySendButton(input);
      if (!button) {
        stableCount = 0;
        return null;
      }
      stableCount += 1;
      return stableCount >= SEND_STABLE_CHECKS ? button : null;
    }, timeoutMs);
  }

  function waitForResult(getResult, timeoutMs) {
    return new Promise((resolve) => {
      const startedAt = Date.now();
      let settled = false;
      let pollTimer = null;
      let timeoutTimer = null;

      const done = (result) => {
        if (settled) {
          return;
        }
        settled = true;
        if (pollTimer) {
          clearInterval(pollTimer);
        }
        if (timeoutTimer) {
          clearTimeout(timeoutTimer);
        }
        resolve(result || null);
      };

      const checkNow = () => {
        const result = getResult();
        if (result) {
          done(result);
          return true;
        }
        if (Date.now() - startedAt >= timeoutMs) {
          done(null);
          return true;
        }
        return false;
      };

      if (checkNow()) {
        return;
      }

      pollTimer = setInterval(checkNow, 180);
      timeoutTimer = setTimeout(() => done(null), timeoutMs + 120);
    });
  }

  function isButtonEnabled(button) {
    return !button.hasAttribute("disabled") && button.getAttribute("aria-disabled") !== "true";
  }

  function getSendSearchRoots(input) {
    const roots = [
      input?.closest?.("form"),
      input?.parentElement,
      input?.parentElement?.parentElement,
      document
    ].filter(Boolean);
    return Array.from(new Set(roots));
  }

  function areaOf(el) {
    const rect = el.getBoundingClientRect();
    return Math.max(0, rect.width) * Math.max(0, rect.height);
  }
})();
