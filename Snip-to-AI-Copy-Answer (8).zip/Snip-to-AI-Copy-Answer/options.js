const SHORTCUTS_FALLBACK_URL = "chrome://extensions/shortcuts";
const FOCUS_DESTINATION_AFTER_UPLOAD_KEY = "focusDestinationAfterUpload";
const SHORTCUTS_BY_BROWSER = {
  chrome: "chrome://extensions/shortcuts",
  edge: "edge://extensions/shortcuts",
  brave: "brave://extensions/shortcuts",
  vivaldi: "vivaldi://extensions/shortcuts",
  opera: "opera://extensions/shortcuts",
  arc: "arc://extensions/shortcuts"
};
const TELEGRAM_CLAW_STORAGE_KEY = "telegramClaw";
const OPENCLAW_HASH = "#openclaw-telegram";
const MAX_RECIPIENTS = 8;
const TELEGRAM_CLAW_DEFAULT = {
  // Legacy global token kept only for backward-compatible migration.
  botToken: "",
  recipients: [],
  lastRecipientId: ""
};

const shortcutHintEl = document.getElementById("shortcutHint");
const openShortcutsBtn = document.getElementById("openShortcutsBtn");
const shortcutStatusEl = document.getElementById("shortcutStatus");
const focusDestinationAfterUploadInput = document.getElementById("focusDestinationAfterUploadInput");
const openclawSection = document.getElementById("openclaw-telegram");

const telegramTokenRow = document.getElementById("telegramTokenRow");
const telegramChatRow = document.getElementById("telegramChatRow");
const webhookEndpointRow = document.getElementById("webhookEndpointRow");
const recipientBotTokenInput = document.getElementById("recipientBotTokenInput");
const saveBotTokenBtn = document.getElementById("saveBotTokenBtn");
const recipientNameInput = document.getElementById("recipientNameInput");
const recipientTypeSelect = document.getElementById("recipientTypeSelect");
const recipientChatIdInput = document.getElementById("recipientChatIdInput");
const recipientEndpointInput = document.getElementById("recipientEndpointInput");
const recipientEnabledInput = document.getElementById("recipientEnabledInput");
const testConnectionBtn = document.getElementById("testConnectionBtn");
const addRecipientBtn = document.getElementById("addRecipientBtn");
const cancelEditBtn = document.getElementById("cancelEditBtn");
const recipientList = document.getElementById("recipientList");
const recipientCountBadge = document.getElementById("recipientCountBadge");
const recipientLimitWarning = document.getElementById("recipientLimitWarning");
const editModeLabel = document.getElementById("editModeLabel");
const telegramStatus = document.getElementById("telegramStatus");

let telegramClawConfig = { ...TELEGRAM_CLAW_DEFAULT };
let editingRecipientId = "";
let statusTimeout = null;
let shortcutStatusTimeout = null;

void init();

async function init() {
  if (shortcutHintEl) {
    shortcutHintEl.textContent = getDefaultShortcutForPlatform();
  }

  if (openShortcutsBtn) {
    openShortcutsBtn.addEventListener("click", async () => {
      const result = await openShortcutSettings();
      if (result.ok) {
        showShortcutStatus(
          result.usedFallback ? "Opened shortcut settings (fallback)." : "Opened shortcut settings."
        );
        return;
      }
      showShortcutStatus("Open your browser's extensions shortcuts page.", true);
    });
  }

  if (focusDestinationAfterUploadInput) {
    focusDestinationAfterUploadInput.addEventListener("change", async () => {
      await chrome.storage.sync.set({
        [FOCUS_DESTINATION_AFTER_UPLOAD_KEY]: Boolean(focusDestinationAfterUploadInput.checked)
      });
      showShortcutStatus("Upload redirect preference saved.");
    });
  }

  if (recipientTypeSelect) {
    recipientTypeSelect.addEventListener("change", toggleRecipientTypeInputs);
  }

  if (saveBotTokenBtn) {
    saveBotTokenBtn.addEventListener("click", onSaveBotToken);
  }

  if (addRecipientBtn) {
    addRecipientBtn.addEventListener("click", onSubmitRecipient);
  }

  if (testConnectionBtn) {
    testConnectionBtn.addEventListener("click", onTestConnection);
  }

  if (cancelEditBtn) {
    cancelEditBtn.addEventListener("click", onCancelEdit);
  }

  const stored = await chrome.storage.local.get({ [TELEGRAM_CLAW_STORAGE_KEY]: TELEGRAM_CLAW_DEFAULT });
  telegramClawConfig = normalizeTelegramClawConfig(stored[TELEGRAM_CLAW_STORAGE_KEY]);
  const syncData = await chrome.storage.sync.get({ [FOCUS_DESTINATION_AFTER_UPLOAD_KEY]: false });

  if (focusDestinationAfterUploadInput) {
    focusDestinationAfterUploadInput.checked = Boolean(syncData[FOCUS_DESTINATION_AFTER_UPLOAD_KEY]);
  }

  setEditMode("");
  toggleRecipientTypeInputs();
  renderRecipientList();
  focusOpenClawSectionFromHash();
}

async function onSaveBotToken() {
  const type = recipientTypeSelect?.value === "webhook" ? "webhook" : "telegram_bot";
  if (type !== "telegram_bot") {
    showTelegramStatus("Save Token is only used for Telegram Bot Chat.", true);
    return;
  }

  const botToken = String(recipientBotTokenInput?.value || "").trim();
  if (!botToken) {
    showTelegramStatus("Telegram bot token is required before saving.", true);
    return;
  }

  if (recipientBotTokenInput) {
    recipientBotTokenInput.value = botToken;
  }
  showTelegramStatus("Token saved. Click Activate Connection to create/update.");
}

async function onSubmitRecipient() {
  const type = recipientTypeSelect?.value === "webhook" ? "webhook" : "telegram_bot";
  const inEditMode = Boolean(editingRecipientId);

  if (!inEditMode && telegramClawConfig.recipients.length >= MAX_RECIPIENTS) {
    showTelegramStatus("Max 8 reached. Edit or remove one to add new.", true);
    updateLimitUi();
    return;
  }

  const fromForm = readRecipientFromForm(type);
  if (!fromForm.ok) {
    showTelegramStatus(fromForm.error, true);
    return;
  }

  if (inEditMode) {
    const index = telegramClawConfig.recipients.findIndex((value) => value.id === editingRecipientId);
    if (index < 0) {
      setEditMode("");
      showTelegramStatus("Selected connection no longer exists.", true);
      renderRecipientList();
      return;
    }

    telegramClawConfig.recipients[index] = {
      id: editingRecipientId,
      ...fromForm.value
    };
    await saveTelegramClawConfig();
    setEditMode("");
    clearRecipientInputs();
    renderRecipientList();
    showTelegramStatus("Connection updated and activated.");
    return;
  }

  const nextRecipient = {
    id: createRecipientId(),
    ...fromForm.value
  };

  telegramClawConfig.recipients.push(nextRecipient);
  if (!telegramClawConfig.lastRecipientId) {
    telegramClawConfig.lastRecipientId = nextRecipient.id;
  }

  await saveTelegramClawConfig();
  clearRecipientInputs();
  renderRecipientList();
  showTelegramStatus("Connection activated.");
}

async function onTestConnection() {
  const type = recipientTypeSelect?.value === "webhook" ? "webhook" : "telegram_bot";
  if (type !== "telegram_bot") {
    showTelegramStatus("Webhook test is not available. Use Activate Connection and test with a screenshot.");
    return;
  }

  const fromForm = readRecipientFromForm(type);
  if (!fromForm.ok) {
    showTelegramStatus(fromForm.error, true);
    return;
  }

  if (testConnectionBtn) {
    testConnectionBtn.disabled = true;
  }

  try {
    const response = await chrome.runtime.sendMessage({
      type: "TEST_TELEGRAM_CONNECTION",
      botToken: fromForm.value.botToken,
      chatId: fromForm.value.chatId
    });

    if (response?.ok) {
      showTelegramStatus("Telegram connection test successful.");
      return;
    }

    showTelegramStatus(
      response?.message || "Telegram connection test failed.",
      true
    );
  } catch (_error) {
    showTelegramStatus("Telegram connection test failed.", true);
  } finally {
    if (testConnectionBtn) {
      testConnectionBtn.disabled = false;
    }
  }
}

function onCancelEdit() {
  setEditMode("");
  showTelegramStatus("Edit canceled.");
}

function readRecipientFromForm(type) {
  const name = String(recipientNameInput?.value || "").trim() || defaultRecipientName(type);
  const enabled = Boolean(recipientEnabledInput?.checked);
  const base = { name, type, enabled };

  if (type === "telegram_bot") {
    const botToken = String(recipientBotTokenInput?.value || "").trim();
    const chatId = String(recipientChatIdInput?.value || "").trim();
    if (!botToken) {
      return { ok: false, error: "Telegram connection requires bot token." };
    }
    if (!chatId) {
      return { ok: false, error: "Telegram connection requires chat_id." };
    }
    return { ok: true, value: { ...base, botToken, chatId } };
  }

  const endpointUrl = String(recipientEndpointInput?.value || "").trim();
  if (!isValidHttpsUrl(endpointUrl)) {
    return { ok: false, error: "OpenClaw/Webhook connection requires a valid https URL." };
  }
  return { ok: true, value: { ...base, endpointUrl } };
}

function renderRecipientList() {
  if (!recipientList) {
    return;
  }

  recipientList.innerHTML = "";

  if (!telegramClawConfig.recipients.length) {
    const emptyItem = document.createElement("li");
    emptyItem.className = "recipient-item";
    emptyItem.textContent = "No OpenClaw/Telegram connections configured yet.";
    recipientList.appendChild(emptyItem);
    updateLimitUi();
    return;
  }

  for (const recipient of telegramClawConfig.recipients) {
    const item = document.createElement("li");
    item.className = "recipient-item";

    const name = document.createElement("div");
    name.className = "recipient-name";
    const isLast = recipient.id === telegramClawConfig.lastRecipientId;
    const stateLabel = recipient.enabled === false ? "disabled" : "enabled";
    name.textContent = `${recipient.name}${isLast ? " (last)" : ""} - ${stateLabel}`;

    const meta = document.createElement("div");
    meta.className = "recipient-meta";
    meta.textContent = recipient.type === "telegram_bot"
      ? `telegram_bot - chat_id: ${recipient.chatId || "(missing)"} - token: ${recipient.botToken ? "saved" : "(missing)"}`
      : `webhook - ${recipient.endpointUrl || "(missing endpoint)"}`;

    const actions = document.createElement("div");
    actions.className = "recipient-actions";

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "btn";
    editBtn.textContent = "Edit";
    editBtn.addEventListener("click", () => {
      loadRecipientIntoForm(recipient.id);
    });

    const setLastBtn = document.createElement("button");
    setLastBtn.type = "button";
    setLastBtn.className = "btn";
    setLastBtn.textContent = "Use as last";
    setLastBtn.addEventListener("click", () => {
      void setLastRecipient(recipient.id);
    });

    const toggleBtn = document.createElement("button");
    toggleBtn.type = "button";
    toggleBtn.className = "btn";
    toggleBtn.textContent = recipient.enabled === false ? "Enable" : "Disable";
    toggleBtn.addEventListener("click", () => {
      void toggleRecipientEnabled(recipient.id);
    });

    const removeBtn = document.createElement("button");
    removeBtn.type = "button";
    removeBtn.className = "btn";
    removeBtn.textContent = "Remove";
    removeBtn.addEventListener("click", () => {
      void removeRecipient(recipient.id);
    });

    actions.appendChild(editBtn);
    actions.appendChild(setLastBtn);
    actions.appendChild(toggleBtn);
    actions.appendChild(removeBtn);

    item.appendChild(name);
    item.appendChild(meta);
    item.appendChild(actions);
    recipientList.appendChild(item);
  }

  updateLimitUi();
}

function loadRecipientIntoForm(recipientId) {
  const recipient = telegramClawConfig.recipients.find((value) => value.id === recipientId);
  if (!recipient) {
    showTelegramStatus("Connection not found.", true);
    return;
  }

  if (recipientNameInput) {
    recipientNameInput.value = recipient.name || "";
  }
  if (recipientTypeSelect) {
    recipientTypeSelect.value = recipient.type === "webhook" ? "webhook" : "telegram_bot";
  }
  if (recipientEnabledInput) {
    recipientEnabledInput.checked = recipient.enabled !== false;
  }
  if (recipientChatIdInput) {
    recipientChatIdInput.value = recipient.type === "telegram_bot" ? String(recipient.chatId || "") : "";
  }
  if (recipientBotTokenInput) {
    recipientBotTokenInput.value = recipient.type === "telegram_bot" ? String(recipient.botToken || "") : "";
  }
  if (recipientEndpointInput) {
    recipientEndpointInput.value = recipient.type === "webhook" ? String(recipient.endpointUrl || "") : "";
  }

  setEditMode(recipient.id);
  toggleRecipientTypeInputs();
  showTelegramStatus("Editing connection.");
}

function setEditMode(recipientId) {
  editingRecipientId = String(recipientId || "");
  const inEditMode = Boolean(editingRecipientId);

  if (editModeLabel) {
    editModeLabel.textContent = inEditMode ? "Mode: Edit connection" : "Mode: Add new connection";
  }
  if (addRecipientBtn) {
    addRecipientBtn.textContent = inEditMode ? "Update Connection" : "Activate Connection";
  }
  if (cancelEditBtn) {
    cancelEditBtn.hidden = !inEditMode;
  }

  updateLimitUi();
}

function updateLimitUi() {
  const count = Array.isArray(telegramClawConfig.recipients) ? telegramClawConfig.recipients.length : 0;
  const inEditMode = Boolean(editingRecipientId);
  const isFull = count >= MAX_RECIPIENTS;

  if (recipientCountBadge) {
    recipientCountBadge.textContent = `${count}/${MAX_RECIPIENTS}`;
  }

  if (recipientLimitWarning) {
    recipientLimitWarning.textContent = isFull
      ? "Max 8 reached. Edit or remove one to add new."
      : "";
  }

  if (addRecipientBtn) {
    addRecipientBtn.disabled = isFull && !inEditMode;
  }
}

async function setLastRecipient(recipientId) {
  telegramClawConfig.lastRecipientId = recipientId;
  await saveTelegramClawConfig();
  renderRecipientList();
  showTelegramStatus("Last connection updated.");
}

async function toggleRecipientEnabled(recipientId) {
  const recipient = telegramClawConfig.recipients.find((value) => value.id === recipientId);
  if (!recipient) {
    return;
  }
  recipient.enabled = recipient.enabled === false;
  await saveTelegramClawConfig();
  renderRecipientList();
  showTelegramStatus("Connection updated.");
}

async function removeRecipient(recipientId) {
  telegramClawConfig.recipients = telegramClawConfig.recipients.filter((value) => value.id !== recipientId);

  if (telegramClawConfig.lastRecipientId === recipientId) {
    telegramClawConfig.lastRecipientId = telegramClawConfig.recipients[0]?.id || "";
  }

  if (editingRecipientId === recipientId) {
    setEditMode("");
  }

  await saveTelegramClawConfig();
  renderRecipientList();
  showTelegramStatus("Connection removed.");
}

function toggleRecipientTypeInputs() {
  const isWebhook = recipientTypeSelect?.value === "webhook";
  const isTelegram = !isWebhook;

  if (telegramTokenRow) {
    telegramTokenRow.hidden = !isTelegram;
  }
  if (telegramChatRow) {
    telegramChatRow.hidden = !isTelegram;
  }
  if (webhookEndpointRow) {
    webhookEndpointRow.hidden = !isWebhook;
  }
  if (saveBotTokenBtn) {
    saveBotTokenBtn.hidden = !isTelegram;
  }
  if (testConnectionBtn) {
    testConnectionBtn.hidden = !isTelegram;
  }
}

function clearRecipientInputs() {
  if (recipientNameInput) {
    recipientNameInput.value = "";
  }
  if (recipientEnabledInput) {
    recipientEnabledInput.checked = true;
  }
  if (recipientChatIdInput) {
    recipientChatIdInput.value = "";
  }
  if (recipientBotTokenInput) {
    recipientBotTokenInput.value = "";
  }
  if (recipientEndpointInput) {
    recipientEndpointInput.value = "";
  }
}

async function saveTelegramClawConfig() {
  telegramClawConfig = normalizeTelegramClawConfig(telegramClawConfig);
  await chrome.storage.local.set({ [TELEGRAM_CLAW_STORAGE_KEY]: telegramClawConfig });
}

function normalizeTelegramClawConfig(value) {
  const raw = value && typeof value === "object" ? value : {};
  const legacyBotToken = String(raw.botToken || "").trim();
  const recipients = Array.isArray(raw.recipients) ? raw.recipients : [];
  const normalizedRecipients = recipients
    .map((recipient) => normalizeRecipient(recipient, legacyBotToken))
    .filter(Boolean)
    .slice(0, MAX_RECIPIENTS);

  const lastRecipientId = String(raw.lastRecipientId || "");
  const hasLast = normalizedRecipients.some((recipient) => recipient.id === lastRecipientId);

  return {
    botToken: legacyBotToken,
    recipients: normalizedRecipients,
    lastRecipientId: hasLast ? lastRecipientId : normalizedRecipients[0]?.id || ""
  };
}

function normalizeRecipient(value, legacyBotToken = "") {
  if (!value || typeof value !== "object") {
    return null;
  }

  const type = value.type === "webhook" ? "webhook" : "telegram_bot";
  const normalized = {
    id: String(value.id || createRecipientId()),
    name: String(value.name || "").trim() || defaultRecipientName(type),
    type,
    enabled: value.enabled !== false
  };

  if (type === "telegram_bot") {
    normalized.botToken = String(value.botToken || legacyBotToken || "").trim();
    normalized.chatId = String(value.chatId || "").trim();
  } else {
    normalized.endpointUrl = String(value.endpointUrl || "").trim();
  }

  return normalized;
}

function defaultRecipientName(type) {
  return type === "telegram_bot" ? "Telegram connection" : "OpenClaw/Webhook connection";
}

function createRecipientId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") {
    return crypto.randomUUID();
  }
  return `recipient-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
}

function isValidHttpsUrl(urlValue) {
  try {
    const url = new URL(urlValue);
    return url.protocol === "https:";
  } catch (_error) {
    return false;
  }
}

function showTelegramStatus(message, isError = false) {
  if (!telegramStatus) {
    return;
  }

  telegramStatus.textContent = message;
  telegramStatus.style.color = isError ? "#a81414" : "#0a6522";

  if (statusTimeout) {
    clearTimeout(statusTimeout);
  }
  statusTimeout = setTimeout(() => {
    telegramStatus.textContent = "";
  }, 2600);
}

function focusOpenClawSectionFromHash() {
  if (window.location.hash !== OPENCLAW_HASH || !openclawSection) {
    return;
  }
  setTimeout(() => {
    openclawSection.scrollIntoView({ block: "start", behavior: "smooth" });
    openclawSection.focus();
  }, 0);
}

function getDefaultShortcutForPlatform() {
  const platform = (
    navigator.userAgentData?.platform ||
    navigator.platform ||
    ""
  ).toLowerCase();
  return platform.includes("mac") ? "Command+Shift+Y" : "Alt+Shift+S";
}

function getShortcutSettingsUrl() {
  const browserKey = detectBrowserKey();
  return SHORTCUTS_BY_BROWSER[browserKey] || SHORTCUTS_FALLBACK_URL;
}

function detectBrowserKey() {
  const tokens = getUserAgentTokens();
  const haystack = tokens.join(" ");
  if (/\bedg\//i.test(haystack) || /microsoft edge/i.test(haystack)) {
    return "edge";
  }
  if (/brave/i.test(haystack)) {
    return "brave";
  }
  if (/vivaldi/i.test(haystack)) {
    return "vivaldi";
  }
  if (/\bopr\//i.test(haystack) || /opera/i.test(haystack)) {
    return "opera";
  }
  if (/\barc\b/i.test(haystack) || /the browser company/i.test(haystack)) {
    return "arc";
  }
  if (/chrome|chromium/i.test(haystack)) {
    return "chrome";
  }
  return "chrome";
}

function getUserAgentTokens() {
  const brands = Array.isArray(navigator.userAgentData?.brands) ? navigator.userAgentData.brands : [];
  const brandStrings = brands.map((brand) => brand?.brand).filter(Boolean);
  const ua = navigator.userAgent || "";
  return [...brandStrings, ua].map((value) => String(value).toLowerCase());
}

async function openShortcutSettings() {
  const primaryUrl = getShortcutSettingsUrl();
  try {
    await chrome.tabs.create({ url: primaryUrl });
    return { ok: true, usedFallback: false, url: primaryUrl };
  } catch (_error) {
    if (primaryUrl === SHORTCUTS_FALLBACK_URL) {
      return { ok: false };
    }
  }

  try {
    await chrome.tabs.create({ url: SHORTCUTS_FALLBACK_URL });
    return { ok: true, usedFallback: true, url: SHORTCUTS_FALLBACK_URL };
  } catch (_error) {
    return { ok: false };
  }
}

function showShortcutStatus(message, isError = false) {
  if (!shortcutStatusEl) {
    return;
  }

  shortcutStatusEl.textContent = message;
  shortcutStatusEl.style.color = isError ? "#a81414" : "#0a6522";

  if (shortcutStatusTimeout) {
    clearTimeout(shortcutStatusTimeout);
  }
  shortcutStatusTimeout = setTimeout(() => {
    shortcutStatusEl.textContent = "";
  }, 2600);
}
