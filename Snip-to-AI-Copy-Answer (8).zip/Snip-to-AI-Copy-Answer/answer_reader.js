(() => {
  const roots=[document];
  for(let i=0;i<roots.length;i++) for(const el of roots[i].querySelectorAll('*')) if(el.shadowRoot) roots.push(el.shadowRoot);
  const all=selector=>roots.flatMap(root=>Array.from(root.querySelectorAll(selector)));
  const answerRoot='[data-markdown-text-style="assistant-message"]';
  const assistant='[data-message-author-role="assistant"],[data-turn="assistant"],[data-role="assistant"],[data-testid="assistant-message"],[data-testid="assistant-response"],[data-author="assistant"]';
  const user='[data-message-author-role="user"],[data-turn="user"],[data-role="user"],[data-author="user"]';
  const final='[data-message-channel="final"],[data-channel="final"]';
  const progress='[data-message-channel="analysis"],[data-message-channel="commentary"],[data-channel="analysis"],[data-channel="commentary"],[data-testid*="reasoning"],[data-testid*="thinking"],details';
  const block='[data-markdown-text-style="assistant-message"],.markdown,.prose,[data-testid="message-content"],[class*="markdown"]';
  const shell='article,[data-testid^="conversation-turn"],[data-message-id]';
  const controls='[data-testid="copy-turn-action-button"],button[aria-label="Copy response" i]';
  const exclude='[data-testid="chatgpt-citation"],[data-search-result-target],button,nav,svg,[aria-hidden="true"],textarea,[contenteditable="true"],script,style';
  const read=node=>{
    const copy=node.cloneNode(true);
    copy.querySelectorAll(progress+','+exclude).forEach(n=>n.remove());
    const chunks=Array.from(copy.querySelectorAll(block));
    const outer=chunks.filter(n=>!chunks.some(p=>p!==n&&p.contains(n)));
    const text=outer.length?outer.map(n=>n.innerText||n.textContent||'').join('\n\n'):(copy.innerText||copy.textContent||'');
    return text.replace(/^\s*(ChatGPT|Assistant) said:\s*/i,'').trim();
  };
  const likelyProgress=text=>/^(?:Response:\s*)?(?:(?:I[’']ll|I will|Let me)\s+(?:check|read|open|look at|review|analy[sz]e|inspect)\b|(?:I[’']ll|I will)\s+give\b)/i.test(text)||
    /^Response:\s*(?:question|screenshot|image)\b/i.test(text);
  const visible=el=>getComputedStyle(el).display!=='none'&&getComputedStyle(el).visibility!=='hidden';
  const busy=all('button[data-testid="stop-button"],button[aria-label*="stop generating" i],button[aria-label*="stop streaming" i],button[aria-label="Stop" i]').some(el=>!el.disabled&&visible(el));
  const users=all(user), lastUser=users.at(-1);
  let turns=all(assistant).filter(n=>!n.closest(progress));
  turns.push(...all(answerRoot).filter(n=>!n.closest(progress)));
  // Include labeled turns when the page omits assistant role attributes.
  turns.push(...all(final).filter(n=>!n.closest(progress)).map(n=>n.closest('article,[data-testid^="conversation-turn"]')||n));
  turns.push(...all(shell).filter(n=>!n.matches(user)&&!n.querySelector(user)&&
    (n.querySelector(controls)||Array.from(n.querySelectorAll('h5,h6,[data-testid="author-label"]')).some(h=>/^(ChatGPT|Assistant)( said)?:?$/i.test(h.textContent.trim())))));
  turns=[...new Set(turns)].filter(n=>!turns.some(p=>p!==n&&p.contains(n)&&!n.matches(answerRoot)));
  turns=turns.filter(n=>!turns.some(p=>p!==n&&n.contains(p)&&p.matches(answerRoot)));
  if(!turns.length)turns=all('main '+block.split(',').join(',main ')).filter(n=>!n.closest(user+',form,[contenteditable="true"],nav,aside,'+progress));
  const markedAnswers=all(answerRoot).filter(n=>!n.closest(progress));
  if(markedAnswers.length)turns=markedAnswers;
  turns.sort((a,b)=>a.compareDocumentPosition(b)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
  const turn=turns.at(-1);
  const beforeUser=turn&&lastUser&&Boolean(turn.compareDocumentPosition(lastUser)&Node.DOCUMENT_POSITION_FOLLOWING);
  let text='', complete=false, method='none';
  if(turn&&!beforeUser){
    // This ChatGPT layout marks the rendered answer independently of role wrappers.
    const answerNodes=[...(turn.matches(answerRoot)?[turn]:[]),...turn.querySelectorAll(answerRoot)].filter(n=>!n.closest(progress));
    const answerNode=answerNodes.at(-1);
    if(answerNode){text=read(answerNode);method='assistant-markdown';}
    // Final channel is the strongest signal. Progress and the answer may be separate nodes in one turn.
    const finalNodes=[...(turn.matches(final)?[turn]:[]),...turn.querySelectorAll(final)].filter(n=>!n.closest(progress));
    const finalNode=finalNodes.at(-1);
    if(!text&&finalNode){text=read(finalNode);complete=!busy&&Boolean(text);method='final-channel';}
    if(!text){
      const messages=Array.from(turn.querySelectorAll(assistant)).filter(n=>!n.closest(progress));
      const nodes=messages.length?messages:[turn];
      const candidate=nodes.at(-1);
      text=read(candidate);method='assistant';
      const turnScope=candidate.closest('article,[data-testid^="conversation-turn"]')||turn;
      complete=!busy&&Boolean(turnScope.querySelector(controls));
    }
    // Progress text is never offered as an answer or copied, even if it sits in an assistant wrapper.
    if(likelyProgress(text)){text='';complete=false;method='progress';}
  }
  return {text:text.slice(0,100000),count:turns.length,busy,complete,url:location.href,
    markdownCount:all(block).length,method,
    pageState:beforeUser?'Latest visible message is your prompt.':method==='progress'?'Progress text found; waiting for the final answer.':!turns.length?'No assistant message found.':text?'Answer text found.':'Latest reply block is empty.'};
})();
