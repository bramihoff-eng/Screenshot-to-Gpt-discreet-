# Snip to AI — Revision 9 (1.0.14)

## Set it up once
1. Sign in to ChatGPT in Chrome.
2. Click the extension's toolbar icon, marked **R9** over the original logo.
3. Choose the conversation under **Send screenshots to**. It saves immediately.
4. If your chat is missing, open **Use a chat link instead**, paste its full ChatGPT conversation URL, and click **Save this chat**.

## Take screenshots
Click **Take screenshot** in the toolbar popup, or press Command+Shift+Y on Mac / Alt+Shift+S on Windows.
Drag over an area of the current browser tab. The screenshot automatically goes to your saved conversation. There is no chat chooser after capture.

A small 24 × 24 pixel gray button appears at the bottom right. It shows C while waiting and I when a completed response is detected. Click it to open the reply panel. The reply reader requests fresh snapshots directly from the ChatGPT tab while you remain on the source page. The latest received answer is also available in the toolbar popup under **Latest reply**.

The screenshot still copies to the clipboard. The completed ChatGPT answer automatically replaces it on your clipboard. Copy failures appear inside the gray reply panel. Your chosen ChatGPT tab stays open in the background.

## Install or update
Unzip the archive. In chrome://extensions, turn on Developer mode and use Load unpacked to select the folder containing manifest.json.
Disable/remove earlier copies so only **Snip to AI — R9** handles the shortcut. To update an existing loaded folder, replace its files and press Reload on the extension card. Refresh ChatGPT and the webpage you capture after updating.

## Limits
Works on ordinary Chrome webpage content, not browser settings or the desktop. ChatGPT must be signed in. Upload and answer reading depend on ChatGPT's page layout and may require adjustment after changes to that site. The reply watcher waits up to five minutes. Navigating the source page removes the floating panel; received replies remain in the toolbar's Latest reply section.

Validation: JavaScript syntax, ZIP integrity, and simulated message/DOM tests for saved-chat routing, immediate panel creation, live panel updates, and response detection, clipboard success/failure, and response delivery. A signed-in Chrome end-to-end test was not available during this build.

R9 routes capture notices and status messages into the gray panel. If no reply is found, the panel shows diagnostic block/character counts to help identify unsupported layouts. Reply detection scans assistant markers, labeled conversation turns, message text and open shadow roots.

R9 skips thinking/progress sections and waits for completion controls on the current answer before copying. The final assistant message is read separately from progress messages.

R9 reads the final channel before other assistant text and excludes progress messages. If completion controls are unavailable, a stable answer can still finish after 10 seconds.

R9 supports the supplied ChatGPT answer markup: data-markdown-text-style="assistant-message". It reads that answer block directly and removes citation chips from copied text.
