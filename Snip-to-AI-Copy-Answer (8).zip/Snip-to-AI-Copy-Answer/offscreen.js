chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if(message.target !== "clipboard" || message.type !== "COPY_ANSWER") return;
  const area=document.createElement("textarea");
  area.value=message.text; document.body.appendChild(area); area.select();
  try { const ok=document.execCommand("copy"); respond({ok,error:ok?"":"Chrome declined the clipboard write"}); }
  catch(error){respond({ok:false,error:error.message});}
  finally{area.remove();}
});
