const DEFAULT_PROVIDER_KEY = "chatgpt";
const FOCUS_DESTINATION_AFTER_UPLOAD_KEY = "focusDestinationAfterUpload";
const DEFAULT_RECENT_CHAT_LIMIT = 8;
const MAX_RECENT_CHAT_LIMIT = 20;
const RECENT_CHAT_CACHE_STORAGE_KEY = "recentChatCache";
const MAX_RECENT_CHAT_CACHE_ITEMS_PER_PROVIDER = 50;
const PROVIDER_READY_TIMEOUT_MS = 18000;
const PROVIDER_READY_POLL_MS = 600;
const MAX_TELEGRAM_CLAW_RECIPIENTS = 8;
const TELEGRAM_CLAW_STORAGE_KEY = "telegramClaw";
const TELEGRAM_CLAW_DEFAULT = {
  // Legacy global token kept only for backward-compatible migration.
  botToken: "",
  recipients: [],
  lastRecipientId: ""
};

const PROVIDERS = {
  chatgpt: {
    key: "chatgpt",
    label: "ChatGPT",
    hosts: ["chatgpt.com", "chat.openai.com"],
    urlRe: /https:\/\/(chatgpt\.com|chat\.openai\.com)\//i,
    launchUrl: "https://chatgpt.com/",
    maxFilesPerConversation: 10,
    uploadSelectors: [
      'input[type="file"][accept*="image"]',
      'input[type="file"][aria-label*="upload" i]',
      'input[type="file"]'
    ]
  },
  claude: {
    key: "claude",
    label: "Claude",
    hosts: ["claude.ai"],
    urlRe: /https:\/\/claude\.ai\//i,
    launchUrl: "https://claude.ai/new",
    maxFilesPerConversation: 10,
    uploadSelectors: [
      'input[type="file"][accept*="image"]',
      'input[type="file"][data-testid*="file" i]',
      'input[type="file"]'
    ]
  },
  gemini: {
    key: "gemini",
    label: "Gemini",
    hosts: ["gemini.google.com"],
    urlRe: /https:\/\/gemini\.google\.com\//i,
    launchUrl: "https://gemini.google.com/app",
    maxFilesPerConversation: 10,
    uploadSelectors: [
      'input[type="file"][accept*="image"]',
      'input[type="file"][aria-label*="upload" i]',
      'input[type="file"]'
    ]
  },
  telegram_claw: {
    key: "telegram_claw",
    label: "OpenClaw/Telegram",
    hosts: [],
    urlRe: /$^/,
    launchUrl: "",
    maxFilesPerConversation: 100000,
    uploadSelectors: []
  }
};

const uploadStateByTabId = new Map();

chrome.runtime.onInstalled.addListener(async () => {
  try {
    const data = await chrome.storage.sync.get({ provider: DEFAULT_PROVIDER_KEY });
    if (!PROVIDERS[data.provider]) {
      await chrome.storage.sync.set({ provider: DEFAULT_PROVIDER_KEY });
    }
  } catch (_error) {
    // Ignore storage initialization failures.
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  uploadStateByTabId.delete(tabId);
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (!Object.prototype.hasOwnProperty.call(changeInfo, "url")) {
    return;
  }

  const state = uploadStateByTabId.get(tabId);
  if (!state) {
    return;
  }

  const provider = PROVIDERS[state.providerKey];
  if (!provider) {
    uploadStateByTabId.delete(tabId);
    return;
  }

  const nextKey = conversationKeyFromUrl(provider, changeInfo.url || "");
  if (!nextKey) {
    uploadStateByTabId.delete(tabId);
    return;
  }

  if (state.conversationKey !== nextKey) {
    uploadStateByTabId.set(tabId, {
      providerKey: provider.key,
      conversationKey: nextKey,
      count: 0
    });
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "capture-to-ai") {
    return;
  }
  await startCaptureFlow("quick");
});

void chrome.action.setBadgeText({ text: "R9" });
void chrome.action.setBadgeBackgroundColor({ color: "#444444" });

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "GET_SELECTED_PROVIDER") {
    getSelectedProvider()
      .then((provider) => sendResponse({
        ok: true,
        provider: provider.key,
        providerLabel: provider.label
      }))
      .catch((error) => sendResponse({
        ok: false,
        provider: DEFAULT_PROVIDER_KEY,
        providerLabel: PROVIDERS[DEFAULT_PROVIDER_KEY].label,
        message: error?.message || "Could not load selected provider."
      }));
    return true;
  }

  if (message?.type === "SET_SELECTED_PROVIDER") {
    handleSetSelectedProvider(message)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({
        ok: false,
        provider: DEFAULT_PROVIDER_KEY,
        providerLabel: PROVIDERS[DEFAULT_PROVIDER_KEY].label,
        message: error?.message || "Could not save provider."
      }));
    return true;
  }

  if (message?.type === "START_CAPTURE_FROM_POPUP") {
    handleStartCaptureFromPopup(message)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({
        ok: false,
        code: "CAPTURE_FAILED",
        message: error?.message || "Could not start capture."
      }));
    return true;
  }

  if (message?.type === "GET_RECENT_CHATS") {
    handleGetRecentChats(message, sender)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({
        ok: false,
        chats: [],
        source: "tabs",
        message: error?.message || "Could not fetch recent chats."
      }));
    return true;
  }

  if (message?.type === "TEST_TELEGRAM_CONNECTION") {
    handleTestTelegramConnection(message)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({
        ok: false,
        code: "TELEGRAM_SEND_FAILED",
        message: error?.message || "Telegram connection test failed."
      }));
    return true;
  }

  if (message?.type === "CAPTURE_VISIBLE_TAB") {
    handleCaptureVisibleTab(sender)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({
        ok: false,
        code: "CAPTURE_FAILED",
        message: error?.message || "Could not capture tab."
      }));
    return true;
  }

  if (message?.type === "ROUTE_IMAGE_TO_AI") {
    handleRouteImageToAi(message, sender)
      .then((result) => sendResponse({ ok: result.delivered, ...result }))
      .catch((error) => sendResponse({
        ok: false,
        delivered: false,
        code: "UPLOAD_DISPATCH_FAILED",
        message: error?.message || "Could not upload image."
      }));
    return true;
  }

  if (message?.type === "GET_ANSWER_STATE") {
    pollAnswerState(sender.tab?.id)
      .then(sendResponse)
      .catch(error => sendResponse({ message: "Reply reader: " + error.message, updatedAt: Date.now() }));
    return true;
  }
  if (message?.type === "ANSWER_COMPLETE" || message?.type === "ANSWER_UPDATE") {
    handleAiAnswer(message, sender)
      .then((result) => sendResponse(result))
      .catch((error) => sendResponse({ ok: false, message: error?.message || "Could not copy the answer." }));
    return true;
  }

  if (message?.type === "ANSWER_TIMEOUT") {
    handleAnswerTimeout(message, sender)
      .then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  return false;
});

async function handleSetSelectedProvider(message) {
  const provider = providerFromKey(message?.provider);
  await chrome.storage.sync.set({ provider: provider.key });
  return {
    ok: true,
    provider: provider.key,
    providerLabel: provider.label
  };
}

async function handleStartCaptureFromPopup(message) {
  const startMode = normalizeStartMode(message?.mode);
  // Give the popup time to close so it does not appear in the capture.
  await delay(220);
  const started = await startCaptureFlow(startMode);
  return {
    ok: started
  };
}

async function startCaptureFlow(startMode) {
  const activeTab = await getActiveTab();
  if (!activeTab?.id) {
    return false;
  }

  try {
    await chrome.scripting.executeScript({
      target: { tabId: activeTab.id },
      files: ["selection.js"]
    });
    await chrome.tabs.sendMessage(activeTab.id, {
      type: "START_SNIP_SELECTION",
      startMode: normalizeStartMode(startMode)
    });
    return true;
  } catch (error) {
    if (isUnsupportedSourcePageError(error)) {
      console.info("Snip to AI unavailable on this page.");
      return false;
    }
    console.error("Failed to start capture flow:", error);
    return false;
  }
}

async function getActiveTab() {
  const lastFocusedTabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (lastFocusedTabs[0]?.id) {
    return lastFocusedTabs[0];
  }

  const currentWindowTabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return currentWindowTabs[0] || null;
}

function normalizeStartMode(value) {
  return value === "choose" ? "choose" : "quick";
}

async function handleCaptureVisibleTab(sender) {
  const windowId = sender.tab?.windowId;
  if (typeof windowId !== "number") {
    return {
      ok: false,
      code: "CAPTURE_FAILED",
      message: "No browser window available for capture."
    };
  }

  try {
    const dataUrl = await chrome.tabs.captureVisibleTab(windowId, { format: "png" });
    return {
      ok: true,
      code: "CAPTURE_OK",
      dataUrl
    };
  } catch (error) {
    if (isUnsupportedSourcePageError(error)) {
      return {
        ok: false,
        code: "UNSUPPORTED_SOURCE_PAGE",
        message: "Snip is unavailable on this page."
      };
    }
    return {
      ok: false,
      code: "CAPTURE_FAILED",
      message: error?.message || "Could not capture tab."
    };
  }
}

async function handleGetRecentChats(message, sender) {
  const provider = await getProviderFromMessage(message?.provider);
  const limit = normalizeInteger(message?.limit, DEFAULT_RECENT_CHAT_LIMIT, 1, MAX_RECENT_CHAT_LIMIT);

  if (provider.key === "telegram_claw") {
    const recentRecipients = await getRecentTelegramClawRecipients(limit);
    return {
      ok: true,
      provider: provider.key,
      providerLabel: provider.label,
      chats: recentRecipients,
      source: "tabs"
    };
  }

  const recent = await getRecentChatsForProvider(provider, sender.tab?.windowId, limit);

  return {
    ok: true,
    provider: provider.key,
    providerLabel: provider.label,
    chats: recent.chats,
    source: recent.source,
    scrapeOk: recent.scrapeOk,
    providerTabCount: recent.providerTabCount
  };
}

async function handleRouteImageToAi(payload, sender) {
  const provider = await getProviderFromMessage(payload?.provider);
  if (provider.key === "telegram_claw") {
    return handleRouteImageToTelegramClaw(payload, sender, provider);
  }

  const imageDataUrl = payload?.imageDataUrl;
  const watchAnswer = provider.key === "chatgpt" && payload?.watchAnswer === true;
  const promptText = normalizePromptText(payload?.promptText) ||
    (watchAnswer ? "Answer the question shown in this screenshot. Reply with the answer and a short explanation." : "");
  const sourceTabId = sender.tab?.id;

  if (!imageDataUrl) {
    const failure = {
      delivered: false,
      code: "UPLOAD_DISPATCH_FAILED",
      message: "Missing image data."
    };
    await notifySourceTab(sourceTabId, failure);
    return failure;
  }

  const { savedDestination } = await chrome.storage.local.get("savedDestination");
  if (!savedDestination?.targetChatUrl && !savedDestination?.targetTabId) {
    const failure = { delivered: false, code: "NO_DESTINATION", message: "Choose a ChatGPT chat in the extension toolbar first." };
    await notifySourceTab(sourceTabId, failure);
    return failure;
  }
  await notifySourceTab(sourceTabId, { code: "WAITING", message: "Sending screenshot to your saved chat…", answer: "" });
  const resolution = await resolveDestinationTab(provider, sender.tab?.windowId, savedDestination.targetChatUrl ? { targetChatUrl: savedDestination.targetChatUrl } : savedDestination);
  if (!resolution.ok || !resolution.tab?.id) {
    const failure = {
      delivered: false,
      code: resolution.code || "TARGET_TAB_NOT_FOUND",
      message: resolution.message || `Could not find or open ${provider.label}.`,
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: `${provider.label} - unavailable`
    };
    await notifySourceTab(sourceTabId, failure);
    return failure;
  }

  await chrome.storage.local.set({ savedDestination: { ...savedDestination, targetTabId: resolution.tab.id } });
  let targetTab;
  try {
    targetTab = await chrome.tabs.get(resolution.tab.id);
  } catch (_error) {
    targetTab = resolution.tab;
  }

  const readyResult = await waitForProviderReady(
    provider,
    targetTab.id,
    resolution.created ? PROVIDER_READY_TIMEOUT_MS : 6000
  );
  const pageMetadata = readyResult.metadata || null;
  if (!readyResult.ok) {
    const failure = {
      delivered: false,
      code: readyResult.code || "PROVIDER_NOT_READY",
      message: readyResult.message || `${provider.label} is not ready for uploads yet.`,
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: formatProviderDestinationLabel(provider, targetTab, pageMetadata)
    };
    await notifySourceTab(sourceTabId, failure);
    if (watchAnswer && resolution.created) await closeBackgroundTab(targetTab.id);
    return failure;
  }

  try {
    targetTab = await chrome.tabs.get(targetTab.id);
  } catch (_error) {
    // Keep the tab snapshot from the resolution.
  }

  const limit = ensureUploadLimit(provider, targetTab);
  if (!limit.ok) {
    const failure = {
      ...limit,
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: formatProviderDestinationLabel(provider, targetTab, pageMetadata)
    };
    await notifySourceTab(sourceTabId, failure);
    if (watchAnswer && resolution.created) await closeBackgroundTab(targetTab.id);
    return failure;
  }

  try {
    if (resolution.created) {
      // Give provider apps time to hydrate before first upload attempt.
      await delay(1800);
    }

    await chrome.scripting.executeScript({
      target: { tabId: targetTab.id },
      files: ["ai_uploader.js"]
    });
  } catch (error) {
    const failure = {
      delivered: false,
      code: "SCRIPT_INJECTION_FAILED",
      message: error?.message || `Could not inject uploader into ${provider.label} tab.`,
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: formatProviderDestinationLabel(provider, targetTab, pageMetadata)
    };
    await notifySourceTab(sourceTabId, failure);
    if (watchAnswer && resolution.created) await closeBackgroundTab(targetTab.id);
    return failure;
  }

  let uploadResponse;
  if (watchAnswer) {
    let baseline;
    try { baseline = await readAnswerSnapshots(targetTab.id); }
    catch (error) {
      const failure = { delivered: false, code: "READER_ERROR", message: "Cannot read the ChatGPT tab. Refresh it and retry. " + error.message };
      await notifySourceTab(sourceTabId, failure);
      return failure;
    }
    await chrome.storage.local.set({ [`answerJob_${sourceTabId}`]: {
      targetTabId: targetTab.id, baseline, startedAt: Date.now(), lastText: "", stableSince: 0
    } });
  }
  try {
    uploadResponse = await chrome.tabs.sendMessage(targetTab.id, {
      type: "AI_UPLOAD_IMAGE",
      imageDataUrl,
      target: provider.key,
      providerLabel: provider.label,
      promptText,
      watchAnswer,
      sourceTabId,
      closeAfterAnswer: false,
      preferredSelectors: provider.uploadSelectors,
      waitTimeoutMs: resolution.created ? 18000 : 6000
    });
  } catch (error) {
    const failure = {
      delivered: false,
      code: "UPLOAD_DISPATCH_FAILED",
      message: error?.message || `Could not send upload message to ${provider.label} tab.`,
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: formatProviderDestinationLabel(provider, targetTab, pageMetadata)
    };
    await notifySourceTab(sourceTabId, failure);
    if (watchAnswer && resolution.created) await closeBackgroundTab(targetTab.id);
    return failure;
  }

  if (!uploadResponse?.ok) {
    const failure = {
      delivered: false,
      code: uploadResponse?.code || "UPLOAD_DISPATCH_FAILED",
      message: uploadResponse?.message || uploadResponse?.error || `Could not upload image to ${provider.label}.`,
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: formatProviderDestinationLabel(provider, targetTab, pageMetadata)
    };
    await notifySourceTab(sourceTabId, failure);
    if (watchAnswer && resolution.created) await closeBackgroundTab(targetTab.id);
    return failure;
  }

  incrementUploadCount(targetTab.id, provider.key, limit.conversationKey);
  await recordRecentChatUsage(provider, targetTab, payload?.targetChatUrl, pageMetadata);
  if (!watchAnswer && await shouldFocusDestinationAfterUpload()) {
    await focusDestinationTab(targetTab);
  }

  const success = {
    delivered: true,
    code: uploadResponse.code || "DELIVERED",
    message: watchAnswer ? "Waiting for ChatGPT’s reply…" : uploadResponse.message || `Image uploaded to ${provider.label}.`,
    textRequested: Boolean(uploadResponse.textRequested),
    textSent: uploadResponse.textSent,
    watchAnswer,
    provider: provider.key,
    providerLabel: provider.label,
    destinationLabel: formatProviderDestinationLabel(provider, targetTab, pageMetadata)
  };
  await notifySourceTab(sourceTabId, success);
  return success;
}

async function handleRouteImageToTelegramClaw(payload, sender, provider) {
  const sourceTabId = sender.tab?.id;
  const imageDataUrl = payload?.imageDataUrl;
  if (!imageDataUrl) {
    const failure = {
      delivered: false,
      code: "UPLOAD_DISPATCH_FAILED",
      message: "Missing image data."
    };
    await notifySourceTab(sourceTabId, failure);
    return failure;
  }

  const config = await getTelegramClawConfig();
  const recipients = listUsableTelegramClawRecipients(config.recipients);
  const requestedRecipientId = typeof payload?.targetRecipientId === "string"
    ? payload.targetRecipientId
    : "";

  let recipient = null;
  if (requestedRecipientId) {
    recipient = recipients.find((value) => value.id === requestedRecipientId) || null;
  } else if (config.lastRecipientId) {
    recipient = recipients.find((value) => value.id === config.lastRecipientId) || null;
  }

  if (!recipient) {
    const failure = {
      delivered: false,
      code: requestedRecipientId ? "TELEGRAM_RECIPIENT_NOT_FOUND" : "TELEGRAM_NO_LAST_RECIPIENT",
      message: requestedRecipientId
        ? "Selected OpenClaw/Telegram recipient is unavailable."
        : "No last OpenClaw/Telegram recipient. Choose one from the chooser.",
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: "OpenClaw/Telegram - no recipient"
    };
    await notifySourceTab(sourceTabId, failure);
    return failure;
  }

  const sendResult = await sendImageToTelegramClawRecipient(
    imageDataUrl,
    recipient,
    normalizePromptText(payload?.promptText)
  );
  if (!sendResult.ok) {
    const failure = {
      delivered: false,
      code: sendResult.code || "UPLOAD_DISPATCH_FAILED",
      message: sendResult.message || "Could not send image to OpenClaw/Telegram recipient.",
      provider: provider.key,
      providerLabel: provider.label,
      destinationLabel: formatTelegramDestinationLabel(recipient)
    };
    await notifySourceTab(sourceTabId, failure);
    return failure;
  }

  await setTelegramClawLastRecipient(recipient.id);

  const success = {
    delivered: true,
    code: "DELIVERED",
    message: sendResult.message || `Image sent to ${recipient.name}.`,
    provider: provider.key,
    providerLabel: provider.label,
    destinationLabel: formatTelegramDestinationLabel(recipient)
  };
  await notifySourceTab(sourceTabId, success);
  return success;
}

async function handleTestTelegramConnection(message) {
  const botToken = String(message?.botToken || "").trim();
  const chatId = String(message?.chatId || "").trim();

  if (!botToken) {
    return {
      ok: false,
      code: "TELEGRAM_BOT_TOKEN_MISSING",
      message: "Telegram bot token is missing."
    };
  }

  if (!chatId) {
    return {
      ok: false,
      code: "TELEGRAM_RECIPIENT_NOT_FOUND",
      message: "Telegram chat_id is missing."
    };
  }

  let response;
  try {
    response = await fetch(`https://api.telegram.org/bot${botToken}/sendChatAction`, {
      method: "POST",
      body: new URLSearchParams({
        chat_id: chatId,
        action: "upload_photo"
      })
    });
  } catch (_error) {
    return {
      ok: false,
      code: "TELEGRAM_SEND_FAILED",
      message: "Telegram connection test request failed."
    };
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch (_error) {
    payload = null;
  }

  if (!response.ok || payload?.ok === false) {
    return {
      ok: false,
      code: "TELEGRAM_SEND_FAILED",
      message: mapTelegramSendFailureMessage(response.status, payload?.description)
    };
  }

  return {
    ok: true,
    code: "DELIVERED",
    message: "Telegram connection is valid."
  };
}

async function sendImageToTelegramClawRecipient(imageDataUrl, recipient, promptText) {
  if (recipient.type === "telegram_bot") {
    const chatId = String(recipient.chatId || "").trim();
    if (!chatId) {
      return {
        ok: false,
        code: "TELEGRAM_RECIPIENT_NOT_FOUND",
        message: "Telegram recipient is missing chat_id."
      };
    }

    const cleanedToken = String(recipient.botToken || "").trim();
    if (!cleanedToken) {
      return {
        ok: false,
        code: "TELEGRAM_BOT_TOKEN_MISSING",
        message: "Telegram bot token is missing in this connection."
      };
    }

    const blobResult = await dataUrlToBlobResult(imageDataUrl);
    if (!blobResult.ok) {
      return blobResult;
    }

    const formData = new FormData();
    formData.append("chat_id", chatId);
    formData.append("photo", blobResult.blob, `snip-${Date.now()}.png`);
    if (promptText) {
      formData.append("caption", promptText.slice(0, 1024));
    }

    let response;
    try {
      response = await fetch(`https://api.telegram.org/bot${cleanedToken}/sendPhoto`, {
        method: "POST",
        body: formData
      });
    } catch (_error) {
      return {
        ok: false,
        code: "TELEGRAM_SEND_FAILED",
        message: "Telegram request failed."
      };
    }

    if (!response.ok) {
      let errorDescription = "";
      try {
        const payload = await response.json();
        errorDescription = String(payload?.description || "");
      } catch (_error) {
        // Ignore parse errors for non-JSON responses.
      }
      return {
        ok: false,
        code: "TELEGRAM_SEND_FAILED",
        message: mapTelegramSendFailureMessage(response.status, errorDescription)
      };
    }

    try {
      const payload = await response.json();
      if (!payload?.ok) {
        return {
          ok: false,
          code: "TELEGRAM_SEND_FAILED",
          message: mapTelegramSendFailureMessage(response.status, payload?.description)
        };
      }
    } catch (_error) {
      // Ignore parse failure when HTTP status is OK.
    }

    return {
      ok: true,
      message: `Image sent to ${recipient.name}.`
    };
  }

  const endpointUrl = String(recipient.endpointUrl || "").trim();
  if (!isValidHttpsUrl(endpointUrl)) {
    return {
      ok: false,
      code: "WEBHOOK_SEND_FAILED",
      message: "Webhook recipient has invalid endpoint URL."
    };
  }

  const blobResult = await dataUrlToBlobResult(imageDataUrl);
  if (!blobResult.ok) {
    return blobResult;
  }

  const formData = new FormData();
  formData.append("image", blobResult.blob, `snip-${Date.now()}.png`);
  formData.append("source", "snip2ai");
  formData.append("recipientId", recipient.id);
  formData.append("recipientName", recipient.name);
  formData.append("timestamp", new Date().toISOString());
  if (promptText) {
    formData.append("text", promptText);
  }

  let response;
  try {
    response = await fetch(endpointUrl, {
      method: "POST",
      body: formData
    });
  } catch (_error) {
    return {
      ok: false,
      code: "WEBHOOK_SEND_FAILED",
      message: "Webhook request failed."
    };
  }

  if (!response.ok) {
    return {
      ok: false,
      code: "WEBHOOK_SEND_FAILED",
      message: `Webhook request failed (${response.status}).`
    };
  }

  return {
    ok: true,
    message: `Image sent to ${recipient.name}.`
  };
}

async function dataUrlToBlobResult(dataUrl) {
  try {
    const response = await fetch(dataUrl);
    const blob = await response.blob();
    return {
      ok: true,
      blob
    };
  } catch (_error) {
    return {
      ok: false,
      code: "UPLOAD_DISPATCH_FAILED",
      message: "Could not decode image payload."
    };
  }
}

async function getSelectedProvider() {
  try {
    const data = await chrome.storage.sync.get({ provider: DEFAULT_PROVIDER_KEY });
    return providerFromKey(data.provider);
  } catch (_error) {
    return PROVIDERS[DEFAULT_PROVIDER_KEY];
  }
}

async function getProviderFromMessage(providerKey) {
  if (providerKey && PROVIDERS[providerKey]) {
    return PROVIDERS[providerKey];
  }
  return getSelectedProvider();
}

function providerFromKey(providerKey) {
  return PROVIDERS[providerKey] || PROVIDERS[DEFAULT_PROVIDER_KEY];
}

function normalizePromptText(value) {
  const text = String(value || "").trim();
  if (!text) {
    return "";
  }
  return text.slice(0, 2000);
}

function formatProviderDestinationLabel(provider, tab, metadata = null) {
  const title = normalizeChatTitle(metadata?.title || tab?.title, tab?.url || metadata?.url, provider.label);
  return `${provider.label} - ${title}`;
}

function formatTelegramDestinationLabel(recipient) {
  const recipientName = String(recipient?.name || "").trim() || "connection";
  return `OpenClaw/Telegram - ${recipientName}`;
}

async function shouldFocusDestinationAfterUpload() {
  try {
    const data = await chrome.storage.sync.get({ [FOCUS_DESTINATION_AFTER_UPLOAD_KEY]: false });
    return Boolean(data[FOCUS_DESTINATION_AFTER_UPLOAD_KEY]);
  } catch (_error) {
    return false;
  }
}

async function handleAiAnswer(message, sender) {
  if (!sender.tab?.id || !PROVIDERS.chatgpt.urlRe.test(sender.tab.url || "")) return { ok: false };
  const answer = String(message.answer || "").trim().slice(0, 100000);
  if (!answer) return { ok: false };
  const state = {
    delivered: true, answer, destinationLabel: "ChatGPT",
    code: message.type === "ANSWER_UPDATE" ? "ANSWER_STREAMING" : "ANSWER_READY",
    message: message.type === "ANSWER_UPDATE" ? "ChatGPT is replying…" : "ChatGPT answer ready. Click the gray box."
  };
  await notifySourceTab(Number(message.sourceTabId), state);
  await chrome.storage.local.set({ latestAnswer: state });
  const { savedDestination } = await chrome.storage.local.get("savedDestination");
  if (savedDestination?.targetTabId === sender.tab.id || savedDestination?.targetChatUrl === sender.tab.url) {
    await chrome.storage.local.set({ savedDestination: { ...savedDestination, targetTabId: sender.tab.id, targetChatUrl: sender.tab.url } });
  }
  return { ok: true };
}

async function handleAnswerTimeout(message, sender) {
  if (!sender.tab?.id || !PROVIDERS.chatgpt.urlRe.test(sender.tab.url || "")) return;
  await notifySourceTab(Number(message.sourceTabId) || 0, {
    delivered: false,
    code: "ANSWER_TIMEOUT",
    message: "Could not detect a completed reply. Check the latest answer in the toolbar or try again."
  });
  if (message.closeAfterAnswer) {
    try { await chrome.tabs.remove(sender.tab.id); } catch (_error) { /* Already closed. */ }
  }
}

async function closeBackgroundTab(tabId) {
  try { await chrome.tabs.remove(tabId); } catch (_error) { /* Already closed. */ }
}

async function focusDestinationTab(tab) {
  if (!tab?.id) {
    return;
  }

  try {
    await chrome.tabs.update(tab.id, { active: true });
  } catch (_error) {
    return;
  }

  if (typeof tab.windowId === "number") {
    try {
      await chrome.windows.update(tab.windowId, { focused: true });
    } catch (_error) {
      // Ignore focus failures.
    }
  }
}

async function getTelegramClawConfig() {
  try {
    const stored = await chrome.storage.local.get({ [TELEGRAM_CLAW_STORAGE_KEY]: TELEGRAM_CLAW_DEFAULT });
    return normalizeTelegramClawConfig(stored[TELEGRAM_CLAW_STORAGE_KEY]);
  } catch (_error) {
    return { ...TELEGRAM_CLAW_DEFAULT };
  }
}

async function setTelegramClawLastRecipient(recipientId) {
  const config = await getTelegramClawConfig();
  config.lastRecipientId = String(recipientId || "");
  await chrome.storage.local.set({ [TELEGRAM_CLAW_STORAGE_KEY]: config });
}

async function getRecentTelegramClawRecipients(limit) {
  const config = await getTelegramClawConfig();
  const recipients = listUsableTelegramClawRecipients(config.recipients);

  const ranked = recipients.sort((a, b) => {
    const aIsLast = a.id === config.lastRecipientId ? 1 : 0;
    const bIsLast = b.id === config.lastRecipientId ? 1 : 0;
    if (aIsLast !== bIsLast) {
      return bIsLast - aIsLast;
    }
    return String(a.name).localeCompare(String(b.name));
  });

  return ranked.slice(0, limit).map((recipient) => ({
    id: `recipient:${recipient.id}`,
    title: recipient.name,
    url: "",
    subtitle: recipient.type === "telegram_bot"
      ? `Telegram chat_id: ${recipient.chatId}`
      : `Webhook: ${recipient.endpointUrl}`,
    targetRecipientId: recipient.id
  }));
}

function normalizeTelegramClawConfig(value) {
  const raw = value && typeof value === "object" ? value : {};
  const legacyBotToken = String(raw.botToken || "").trim();
  const recipients = Array.isArray(raw.recipients) ? raw.recipients : [];
  const normalizedRecipients = recipients
    .map((recipient) => normalizeTelegramClawRecipient(recipient, legacyBotToken))
    .filter(Boolean)
    .slice(0, MAX_TELEGRAM_CLAW_RECIPIENTS);

  const lastRecipientId = String(raw.lastRecipientId || "");
  const hasLast = normalizedRecipients.some((recipient) => recipient.id === lastRecipientId);

  return {
    botToken: legacyBotToken,
    recipients: normalizedRecipients,
    lastRecipientId: hasLast ? lastRecipientId : normalizedRecipients[0]?.id || ""
  };
}

function normalizeTelegramClawRecipient(value, legacyBotToken = "") {
  if (!value || typeof value !== "object") {
    return null;
  }

  const type = value.type === "webhook" ? "webhook" : "telegram_bot";
  const normalized = {
    id: String(value.id || ""),
    name: String(value.name || "").trim(),
    type,
    enabled: value.enabled !== false
  };

  if (!normalized.id) {
    return null;
  }

  if (!normalized.name) {
    normalized.name = type === "telegram_bot" ? "Telegram recipient" : "Webhook recipient";
  }

  if (type === "telegram_bot") {
    normalized.botToken = String(value.botToken || legacyBotToken || "").trim();
    normalized.chatId = String(value.chatId || "").trim();
  } else {
    normalized.endpointUrl = String(value.endpointUrl || "").trim();
  }

  return normalized;
}

function listUsableTelegramClawRecipients(recipients) {
  const items = Array.isArray(recipients) ? recipients : [];
  return items.filter((recipient) => {
    if (!recipient || recipient.enabled === false) {
      return false;
    }

    if (recipient.type === "telegram_bot") {
      return Boolean(String(recipient.chatId || "").trim()) && Boolean(String(recipient.botToken || "").trim());
    }

    return isValidHttpsUrl(recipient.endpointUrl);
  });
}

async function resolveDestinationTab(provider, sourceWindowId, destination) {
  const forceNewChat = Boolean(destination?.forceNewChat);
  const targetTabId = Number.isInteger(destination?.targetTabId) ? destination.targetTabId : null;
  const targetChatUrl = typeof destination?.targetChatUrl === "string" ? destination.targetChatUrl : "";

  if (forceNewChat) {
    return createNewProviderTabResolution(provider, sourceWindowId);
  }

  let explicitFailure = null;

  if (targetTabId !== null) {
    const tabResolution = await resolveProviderTabById(provider, targetTabId);
    if (tabResolution.ok) {
      return tabResolution;
    }
    explicitFailure = tabResolution;
  }

  if (targetChatUrl) {
    const urlResolution = await resolveOrCreateProviderTabByUrl(provider, sourceWindowId, targetChatUrl);
    if (urlResolution.ok) {
      return urlResolution;
    }
    explicitFailure = urlResolution;
  }

  if (targetTabId !== null || targetChatUrl) {
    return explicitFailure || {
      ok: false,
      created: false,
      code: "TARGET_TAB_NOT_FOUND",
      message: `Selected ${provider.label} chat is unavailable.`
    };
  }

  return resolveOrCreateProviderTab(provider, sourceWindowId);
}

async function resolveOrCreateProviderTab(provider, sourceWindowId) {
  const existingTab = await findTargetTab(provider, sourceWindowId);
  if (existingTab?.id) {
    return {
      ok: true,
      created: false,
      tab: existingTab
    };
  }

  return createNewProviderTabResolution(provider, sourceWindowId);
}

async function resolveProviderTabById(provider, tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (tab?.url && provider.urlRe.test(tab.url)) {
      return {
        ok: true,
        created: false,
        tab
      };
    }
  } catch (_error) {
    // Fall through to failure.
  }

  return {
    ok: false,
    created: false,
    code: "TARGET_TAB_NOT_FOUND",
    message: `Selected ${provider.label} chat tab is unavailable.`
  };
}

async function resolveOrCreateProviderTabByUrl(provider, sourceWindowId, rawUrl) {
  const normalizedConversationUrl = normalizeConversationUrlForChooser(provider, rawUrl);
  const normalizedUrl = normalizeProviderUrl(provider, rawUrl);
  const desiredUrl = normalizedConversationUrl || normalizedUrl;
  if (!desiredUrl) {
    return {
      ok: false,
      created: false,
      code: "TARGET_TAB_NOT_FOUND",
      message: `Selected ${provider.label} chat URL is invalid.`
    };
  }

  const providerTabs = await getProviderTabs(provider);
  const matchingTabs = providerTabs.filter((tab) => {
    const normalizedTabUrl =
      normalizeConversationUrlForChooser(provider, tab.url || "") ||
      normalizeProviderUrl(provider, tab.url || "");
    return normalizedTabUrl === desiredUrl;
  });

  const existingTab = pickPreferredTab(matchingTabs, sourceWindowId);
  if (existingTab?.id) {
    return {
      ok: true,
      created: false,
      tab: existingTab
    };
  }

  return createProviderTabResolution(provider, sourceWindowId, desiredUrl);
}

async function createNewProviderTabResolution(provider, sourceWindowId) {
  return createProviderTabResolution(provider, sourceWindowId, provider.launchUrl);
}

async function createProviderTabResolution(provider, sourceWindowId, url) {
  let createdTab;
  try {
    createdTab = await createProviderTab(provider, sourceWindowId, url);
  } catch (_error) {
    return {
      ok: false,
      created: false,
      code: "TARGET_TAB_NOT_FOUND",
      message: `Could not open ${provider.label} automatically.`
    };
  }

  if (!createdTab?.id) {
    return {
      ok: false,
      created: false,
      code: "TARGET_TAB_NOT_FOUND",
      message: `Could not open ${provider.label} automatically.`
    };
  }

  await waitForTabComplete(createdTab.id, 18000);

  try {
    return {
      ok: true,
      created: true,
      tab: await chrome.tabs.get(createdTab.id)
    };
  } catch (_error) {
    return {
      ok: true,
      created: true,
      tab: createdTab
    };
  }
}

async function createProviderTab(provider, sourceWindowId, explicitUrl) {
  const createProperties = {
    url: explicitUrl || provider.launchUrl,
    active: false
  };

  if (typeof sourceWindowId === "number") {
    try {
      return await chrome.tabs.create({
        ...createProperties,
        windowId: sourceWindowId
      });
    } catch (_error) {
      // Fall through.
    }
  }

  return chrome.tabs.create(createProperties);
}

function waitForTabComplete(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let settled = false;
    let timeoutId = null;

    const finish = (loaded) => {
      if (settled) {
        return;
      }
      settled = true;
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      chrome.tabs.onUpdated.removeListener(onUpdated);
      resolve(loaded);
    };

    const onUpdated = (updatedTabId, changeInfo) => {
      if (updatedTabId !== tabId) {
        return;
      }
      if (changeInfo.status === "complete") {
        finish(true);
      }
    };

    chrome.tabs.onUpdated.addListener(onUpdated);
    timeoutId = setTimeout(() => finish(false), timeoutMs);

    chrome.tabs.get(tabId)
      .then((tab) => {
        if (tab?.status === "complete") {
          finish(true);
        }
      })
      .catch(() => finish(false));
  });
}

async function notifySourceTab(tabId, status) {
  if (tabId) {
    const key = `answerState_${tabId}`;
    const old = (await chrome.storage.local.get(key))[key] || {};
    await chrome.storage.local.set({ [key]: { ...old, ...status, updatedAt: Date.now() } });
  }
  if (!tabId) {
    return;
  }

  try {
    await chrome.tabs.sendMessage(tabId, {
      type: "SNIP_STATUS",
      delivered: status.delivered,
      code: status.code,
      message: status.message,
      textRequested: status.textRequested,
      textSent: status.textSent,
      provider: status.provider,
      providerLabel: status.providerLabel,
      destinationLabel: status.destinationLabel,
      answer: status.answer
    });
  } catch (_error) {
    // Ignore best-effort status notifications.
  }
}

async function getRecentChatsForProvider(provider, sourceWindowId, limit) {
  const providerTabs = await getProviderTabs(provider);
  let preferredTab = pickPreferredTab(providerTabs, sourceWindowId);
  const cachedChats = await getRecentChatCache(provider);
  let temporaryTab = null;
  if (!preferredTab?.id && provider.key === "chatgpt") {
    try {
      temporaryTab = await createProviderTab(provider, sourceWindowId);
      await waitForTabComplete(temporaryTab.id, 18000);
      await delay(1200);
      preferredTab = temporaryTab;
    } catch (_error) {
      // Cached chats remain available if the temporary tab fails to load.
    }
  }

  let sidebarResult;
  try {
    sidebarResult = preferredTab?.id
      ? await scrapeRecentChatsFromProviderTab(provider, preferredTab.id, Math.max(limit * 3, 12))
      : { ok: true, chats: [] };
  } catch (_error) {
    sidebarResult = { ok: false, chats: [] };
  } finally {
    if (temporaryTab?.id) await closeBackgroundTab(temporaryTab.id);
  }
  const sidebarChats = sidebarResult.chats;
  const normalizedSidebarChats = sidebarChats
    .map((chat, index) => normalizeRecentChat(provider, {
      ...chat,
      source: "sidebar",
      orderIndex: index
    }))
    .filter(Boolean);

  const openTabChats = await getOpenTabRecentChats(provider, providerTabs, sourceWindowId);

  await upsertRecentChatCache(provider, normalizedSidebarChats.concat(openTabChats));

  const mergedByUrl = new Map();
  for (const entry of cachedChats) {
    mergeRecentChatByUrl(mergedByUrl, entry);
  }
  for (const entry of normalizedSidebarChats) {
    mergeRecentChatByUrl(mergedByUrl, entry);
  }
  for (const entry of openTabChats) {
    mergeRecentChatByUrl(mergedByUrl, entry);
  }

  const chats = Array.from(mergedByUrl.values())
    .map(finalizeRecentChatSource)
    .sort(compareRecentChatEntries)
    .slice(0, limit)
    .map(stripRecentChatInternalFields);
  const hasSidebar = normalizedSidebarChats.length > 0;
  const hasTabs = openTabChats.length > 0;
  const hasCache = cachedChats.length > 0;
  const source = [hasSidebar ? "sidebar" : "", hasTabs ? "tabs" : "", hasCache ? "cache" : ""]
    .filter(Boolean)
    .join("+") || "none";
  return {
    chats,
    source,
    scrapeOk: sidebarResult.ok,
    providerTabCount: providerTabs.length
  };
}

async function getProviderTabs(provider) {
  const tabs = await chrome.tabs.query({});
  return tabs.filter((tab) => tab.url && provider.urlRe.test(tab.url));
}

async function getOpenTabRecentChats(provider, providerTabs, sourceWindowId) {
  const entries = await Promise.all(providerTabs.map(async (tab) => {
    const metadata = tab.id ? await scrapeProviderPageMetadata(provider, tab.id) : null;
    return tabToRecentChat(provider, tab, metadata);
  }));
  return entries
    .filter(Boolean)
    .sort((a, b) => compareTabsByIds(providerTabs, a.tabId, b.tabId, sourceWindowId));
}

function compareTabsByIds(providerTabs, aTabId, bTabId, sourceWindowId) {
  const a = providerTabs.find((tab) => tab.id === aTabId);
  const b = providerTabs.find((tab) => tab.id === bTabId);
  if (!a || !b) {
    return 0;
  }
  return compareTabs(a, b, sourceWindowId);
}

async function scrapeRecentChatsFromProviderTab(provider, tabId, limit) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (hosts, maxItems) => {
        const selectors = [
          "aside a[href]",
          "nav a[href]",
          "[role='navigation'] a[href]",
          "main a[href]",
          "a[href]"
        ];

        function cleanText(value) {
          return String(value || "").replace(/\s+/g, " ").trim();
        }

        function isLikelyProjectName(value, chatTitle) {
          const text = cleanText(value);
          if (!text || text.length > 80) {
            return false;
          }

          const lower = text.toLowerCase();
          const blocked = new Set([
            "chatgpt",
            "chats",
            "projects",
            "project",
            "new chat",
            "today",
            "yesterday",
            "previous 7 days",
            "previous 30 days",
            "this month",
            "older",
            "share",
            "settings",
            "search",
            "more",
            "edit",
            "rename",
            "archive",
            "delete"
          ]);
          return !blocked.has(lower) && lower !== cleanText(chatTitle).toLowerCase();
        }

        function textFromElement(element) {
          if (!element) {
            return "";
          }
          return cleanText(
            element.getAttribute("aria-label") ||
            element.getAttribute("title") ||
            element.textContent ||
            ""
          );
        }

        function extractProjectNameFromText(value) {
          const text = cleanText(value);
          const match = text.match(/\bproject\s*[:\-]\s*(.+)$/i);
          return match ? cleanText(match[1]) : "";
        }

        function inferProjectName(anchor, chatTitle) {
          const projectContainer = anchor.closest(
            '[data-testid*="project" i], [aria-label*="project" i], [class*="project" i]'
          );
          if (!projectContainer) {
            return "";
          }

          const explicitLabel = extractProjectNameFromText(
            projectContainer.getAttribute("aria-label") ||
            projectContainer.getAttribute("title") ||
            projectContainer.getAttribute("data-testid") ||
            ""
          );
          if (isLikelyProjectName(explicitLabel, chatTitle)) {
            return explicitLabel;
          }

          const labelCandidates = Array.from(projectContainer.querySelectorAll(
            '[aria-label*="project" i], [title*="project" i], [role="heading"], h1, h2, h3, button[aria-expanded], a[href*="project" i]'
          ));
          for (const candidate of labelCandidates) {
            if (candidate === anchor || anchor.contains(candidate)) {
              continue;
            }

            const text = extractProjectNameFromText(textFromElement(candidate)) || textFromElement(candidate);
            if (isLikelyProjectName(text, chatTitle)) {
              return text;
            }
          }

          return "";
        }

        const seen = new Set();
        const list = [];
        for (const selector of selectors) {
          const anchors = Array.from(document.querySelectorAll(selector));
          for (const anchor of anchors) {
            const hrefAttr = anchor.getAttribute("href");
            if (!hrefAttr) {
              continue;
            }

            let absoluteHref;
            try {
              absoluteHref = new URL(hrefAttr, location.href).href;
            } catch (_error) {
              continue;
            }

            if (seen.has(absoluteHref)) {
              continue;
            }

            let host;
            try {
              host = new URL(absoluteHref).hostname.toLowerCase();
            } catch (_error) {
              continue;
            }
            const hostAllowed = hosts.some((allowed) => host === allowed || host.endsWith(`.${allowed}`));
            if (!hostAllowed) {
              continue;
            }

            const text = textFromElement(anchor);
            const projectName = inferProjectName(anchor, text);

            seen.add(absoluteHref);
            list.push({
              url: absoluteHref,
              title: text,
              projectName
            });
            if (list.length >= maxItems) {
              return list;
            }
          }
        }

        return list;
      },
      args: [provider.hosts, limit]
    });

    const first = Array.isArray(results) ? results[0] : null;
    return {
      ok: true,
      chats: Array.isArray(first?.result) ? first.result : []
    };
  } catch (_error) {
    return {
      ok: false,
      chats: []
    };
  }
}

async function waitForProviderReady(provider, tabId, timeoutMs) {
  if (!tabId) {
    return {
      ok: false,
      code: "PROVIDER_NOT_READY",
      message: `${provider.label} tab is unavailable.`
    };
  }

  const startedAt = Date.now();
  let lastMetadata = null;

  while (Date.now() - startedAt <= timeoutMs) {
    const metadata = await scrapeProviderPageMetadata(provider, tabId);
    lastMetadata = metadata;

    if (metadata.status === "unknown") {
      return {
        ok: true,
        metadata
      };
    }

    if (metadata.status === "not_ready") {
      return {
        ok: false,
        code: "PROVIDER_NOT_READY",
        message: metadata.message || `${provider.label} is not ready for uploads yet.`,
        metadata
      };
    }

    if (metadata.status === "ready") {
      return {
        ok: true,
        metadata
      };
    }

    await delay(PROVIDER_READY_POLL_MS);
  }

  return {
    ok: false,
    code: "PROVIDER_NOT_READY",
    message: lastMetadata?.message || `${provider.label} is still loading. Try again when the chat composer is ready.`,
    metadata: lastMetadata
  };
}

async function scrapeProviderPageMetadata(provider, tabId) {
  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId },
      func: (providerKey, providerLabel) => {
        const currentHref = location.href;
        const currentPath = location.pathname;

        function cleanText(value) {
          return String(value || "").replace(/\s+/g, " ").trim();
        }

        function isVisible(el) {
          if (!el || !(el instanceof Element)) {
            return false;
          }
          const style = window.getComputedStyle(el);
          const rect = el.getBoundingClientRect();
          return (
            style.display !== "none" &&
            style.visibility !== "hidden" &&
            parseFloat(style.opacity || "1") > 0 &&
            rect.width > 0 &&
            rect.height > 0
          );
        }

        function textFromElement(element) {
          if (!element) {
            return "";
          }
          return cleanText(
            element.getAttribute("aria-label") ||
            element.getAttribute("title") ||
            element.textContent ||
            ""
          );
        }

        function isImageCompatibleInput(input) {
          if (!input || input.hasAttribute("disabled")) {
            return false;
          }
          const accept = String(input.getAttribute("accept") || "").toLowerCase();
          return !accept || accept.includes("image") || accept.includes("png") ||
            accept.includes("jpg") || accept.includes("jpeg") || accept.includes("*");
        }

        function hasUploadInput() {
          return Array.from(document.querySelectorAll('input[type="file"]')).some(isImageCompatibleInput);
        }

        function hasPromptComposer() {
          return Array.from(document.querySelectorAll(
            'textarea:not([disabled]), div[contenteditable="true"][role="textbox"], div[contenteditable="true"]'
          )).some((element) => isVisible(element) || element.getAttribute("contenteditable") === "true");
        }

        function hrefMatchesCurrentConversation(anchor) {
          try {
            const parsed = new URL(anchor.href, location.href);
            if (providerKey === "chatgpt") {
              return parsed.pathname.startsWith("/c/") && parsed.pathname === currentPath;
            }
            if (providerKey === "claude") {
              return parsed.pathname.startsWith("/chat/") && parsed.pathname === currentPath;
            }
            if (providerKey === "gemini") {
              return parsed.pathname.startsWith("/app/") && parsed.pathname === currentPath;
            }
            return false;
          } catch (_error) {
            return false;
          }
        }

        function isLikelyProjectName(value, chatTitle) {
          const text = cleanText(value);
          if (!text || text.length > 80) {
            return false;
          }
          const lower = text.toLowerCase();
          const blocked = new Set([
            "chatgpt",
            "chats",
            "projects",
            "project",
            "new chat",
            "today",
            "yesterday",
            "previous 7 days",
            "previous 30 days",
            "this month",
            "older",
            "share",
            "settings",
            "search",
            "more",
            "edit",
            "rename",
            "archive",
            "delete"
          ]);
          return !blocked.has(lower) && lower !== cleanText(chatTitle).toLowerCase();
        }

        function extractProjectNameFromText(value) {
          const text = cleanText(value);
          const match = text.match(/\bproject\s*[:\-]\s*(.+)$/i);
          return match ? cleanText(match[1]) : "";
        }

        function inferProjectName(anchor, chatTitle) {
          const projectContainer = anchor?.closest?.(
            '[data-testid*="project" i], [aria-label*="project" i], [class*="project" i]'
          );
          if (!projectContainer) {
            return "";
          }

          const direct = extractProjectNameFromText(
            projectContainer.getAttribute("aria-label") ||
            projectContainer.getAttribute("title") ||
            projectContainer.getAttribute("data-testid") ||
            ""
          );
          if (isLikelyProjectName(direct, chatTitle)) {
            return direct;
          }

          const candidates = Array.from(projectContainer.querySelectorAll(
            '[aria-label*="project" i], [title*="project" i], [role="heading"], h1, h2, h3, button[aria-expanded], a[href*="project" i]'
          ));
          for (const candidate of candidates) {
            if (candidate === anchor || anchor?.contains?.(candidate)) {
              continue;
            }

            const text = extractProjectNameFromText(textFromElement(candidate)) || textFromElement(candidate);
            if (isLikelyProjectName(text, chatTitle)) {
              return text;
            }
          }

          return "";
        }

        function findCurrentConversationAnchor() {
          const anchors = Array.from(document.querySelectorAll("aside a[href], nav a[href], a[href]"))
            .filter(hrefMatchesCurrentConversation);
          if (!anchors.length) {
            return null;
          }

          anchors.sort((a, b) => {
            const aCurrent = a.getAttribute("aria-current") === "page" ? 1 : 0;
            const bCurrent = b.getAttribute("aria-current") === "page" ? 1 : 0;
            if (aCurrent !== bCurrent) {
              return bCurrent - aCurrent;
            }
            return textFromElement(a).length - textFromElement(b).length;
          });
          return anchors[0] || null;
        }

        function pageLooksNotReady() {
          const href = currentHref.toLowerCase();
          const bodyText = cleanText(document.body?.innerText || "").toLowerCase();
          if (
            href.includes("/auth") ||
            href.includes("/login") ||
            href.includes("oauth") ||
            href.includes("authorize")
          ) {
            return true;
          }
          if (
            bodyText.includes("connect ") && bodyText.includes(" to chatgpt") &&
            (bodyText.includes("authorize") || bodyText.includes("deny"))
          ) {
            return true;
          }
          return (
            bodyText.includes("log in") ||
            bodyText.includes("sign in") ||
            bodyText.includes("sign up") ||
            bodyText.includes("continue with google") ||
            bodyText.includes("verify you are human")
          ) && !hasPromptComposer();
        }

        const activeAnchor = findCurrentConversationAnchor();
        const activeTitle = textFromElement(activeAnchor);
        const projectName = inferProjectName(activeAnchor, activeTitle);
        const ready = hasUploadInput() || hasPromptComposer();

        if (pageLooksNotReady()) {
          return {
            status: "not_ready",
            message: `${providerLabel} opened a setup/login page. Finish it, then try again.`,
            url: currentHref,
            title: activeTitle,
            projectName
          };
        }

        return {
          status: ready ? "ready" : "loading",
          message: ready ? "" : `${providerLabel} is still loading. Try again when the chat composer is ready.`,
          url: currentHref,
          title: activeTitle,
          projectName
        };
      },
      args: [provider.key, provider.label]
    });

    const first = Array.isArray(results) ? results[0] : null;
    const metadata = first?.result && typeof first.result === "object" ? first.result : {};
    return normalizeProviderPageMetadata(provider, metadata);
  } catch (_error) {
    return {
      status: "unknown",
      url: "",
      title: "",
      projectName: ""
    };
  }
}

function normalizeProviderPageMetadata(provider, metadata) {
  const url = normalizeConversationUrlForChooser(provider, metadata?.url || "") ||
    normalizeProviderUrl(provider, metadata?.url || "");
  const rawTitle = String(metadata?.title || "").trim();
  return {
    status: metadata?.status === "ready" || metadata?.status === "not_ready" || metadata?.status === "loading"
      ? metadata.status
      : "unknown",
    message: String(metadata?.message || "").trim(),
    url,
    title: rawTitle ? normalizeChatTitle(rawTitle, url, provider.label) : "",
    projectName: normalizeProjectName(metadata?.projectName)
  };
}

function normalizeRecentChat(provider, candidate) {
  const url = normalizeConversationUrlForChooser(provider, candidate?.url || "");
  if (!url) {
    return null;
  }

  return {
    id: url,
    title: normalizeChatTitle(candidate?.title, url, provider.label),
    url,
    projectName: normalizeProjectName(candidate?.projectName),
    lastUsedAt: normalizeTimestamp(candidate?.lastUsedAt),
    source: normalizeRecentChatSource(candidate?.source),
    orderIndex: normalizeOptionalInteger(candidate?.orderIndex)
  };
}

function tabToRecentChat(provider, tab, metadata = null) {
  const url = normalizeConversationUrlForChooser(provider, tab.url || "");
  if (!url) {
    return null;
  }
  const metadataTitle = metadata?.url === url || !metadata?.url ? metadata?.title : "";
  const title = normalizeChatTitle(metadataTitle || tab.title, url, provider.label);
  const projectName =
    normalizeProjectName(metadata?.projectName) ||
    inferProjectNameFromTabTitle(provider, tab.title, title);

  return {
    id: url,
    title,
    url,
    projectName,
    tabId: tab.id,
    lastUsedAt: normalizeTimestamp(tab.lastAccessed),
    source: "tab"
  };
}

function normalizeChatTitle(rawTitle, url, providerLabel) {
  const cleanTitle = stripProviderTitlePrefix(String(rawTitle || "").replace(/\s+/g, " ").trim(), providerLabel);
  if (cleanTitle) {
    return cleanTitle;
  }

  try {
    const parsed = new URL(url);
    const path = parsed.pathname === "/" ? "New chat" : parsed.pathname;
    return `${providerLabel}: ${path}`;
  } catch (_error) {
    return `${providerLabel} chat`;
  }
}

function stripProviderTitlePrefix(title, providerLabel) {
  let cleanTitle = String(title || "").replace(/\s+/g, " ").trim();
  if (!cleanTitle) {
    return "";
  }

  const escapedLabel = escapeRegExp(providerLabel);
  const prefixRe = new RegExp(`^${escapedLabel}\\s*[-:|]\\s*`, "i");
  while (prefixRe.test(cleanTitle)) {
    cleanTitle = cleanTitle.replace(prefixRe, "").trim();
  }
  return cleanTitle;
}

function inferProjectNameFromTabTitle(provider, tabTitle, chatTitle) {
  if (provider.key !== "chatgpt") {
    return "";
  }

  const tabProject = stripProviderTitlePrefix(tabTitle, provider.label);
  const cleanChatTitle = String(chatTitle || "").replace(/\s+/g, " ").trim();
  if (!tabProject || tabProject.length > 80) {
    return "";
  }
  if (tabProject.toLowerCase() === cleanChatTitle.toLowerCase()) {
    return "";
  }
  return tabProject;
}

function escapeRegExp(value) {
  return String(value || "").replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function normalizeProjectName(value) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (!text || text.length > 80) {
    return "";
  }
  return text;
}

function normalizeTimestamp(value) {
  const numberValue = Number(value);
  return Number.isFinite(numberValue) && numberValue > 0 ? numberValue : 0;
}

function normalizeOptionalInteger(value) {
  return Number.isInteger(value) && value >= 0 ? value : null;
}

function normalizeRecentChatSource(value) {
  return value === "tab" || value === "sidebar" || value === "cache" ? value : "cache";
}

async function getRecentChatCache(provider) {
  try {
    const stored = await chrome.storage.local.get({ [RECENT_CHAT_CACHE_STORAGE_KEY]: {} });
    const cache = stored?.[RECENT_CHAT_CACHE_STORAGE_KEY];
    const providerItems = cache && Array.isArray(cache[provider.key]) ? cache[provider.key] : [];
    return providerItems
      .map((item, index) => normalizeRecentChat(provider, {
        ...item,
        source: "cache",
        orderIndex: index
      }))
      .filter(Boolean);
  } catch (_error) {
    return [];
  }
}

async function upsertRecentChatCache(provider, entries) {
  const normalizedEntries = (Array.isArray(entries) ? entries : [])
    .map((entry) => normalizeRecentChat(provider, entry))
    .filter(Boolean);
  if (!normalizedEntries.length) {
    return;
  }

  try {
    const stored = await chrome.storage.local.get({ [RECENT_CHAT_CACHE_STORAGE_KEY]: {} });
    const cache = stored?.[RECENT_CHAT_CACHE_STORAGE_KEY] &&
      typeof stored[RECENT_CHAT_CACHE_STORAGE_KEY] === "object"
      ? stored[RECENT_CHAT_CACHE_STORAGE_KEY]
      : {};
    const currentItems = Array.isArray(cache[provider.key]) ? cache[provider.key] : [];
    const mergedByUrl = new Map();

    for (const item of currentItems) {
      const normalized = normalizeRecentChat(provider, { ...item, source: "cache" });
      if (normalized) {
        mergeRecentChatByUrl(mergedByUrl, normalized);
      }
    }

    for (const entry of normalizedEntries) {
      mergeRecentChatByUrl(mergedByUrl, entry);
    }

    const nextItems = Array.from(mergedByUrl.values())
      .map(finalizeRecentChatSource)
      .sort(compareRecentChatEntries)
      .slice(0, MAX_RECENT_CHAT_CACHE_ITEMS_PER_PROVIDER)
      .map((entry) => ({
        url: entry.url,
        title: entry.title,
        projectName: entry.projectName || "",
        lastUsedAt: normalizeTimestamp(entry.lastUsedAt)
      }));

    await chrome.storage.local.set({
      [RECENT_CHAT_CACHE_STORAGE_KEY]: {
        ...cache,
        [provider.key]: nextItems
      }
    });
  } catch (_error) {
    // Recent chats are a convenience cache; upload flow should not depend on it.
  }
}

async function recordRecentChatUsage(provider, tab, fallbackUrl, metadata = null) {
  const url =
    normalizeConversationUrlForChooser(provider, fallbackUrl || "") ||
    normalizeConversationUrlForChooser(provider, metadata?.url || "") ||
    normalizeConversationUrlForChooser(provider, tab?.url || "");
  if (!url) {
    return;
  }

  const cachedChats = await getRecentChatCache(provider);
  const existing = cachedChats.find((chat) => chat.url === url);
  const title = normalizeChatTitle(metadata?.title || tab?.title || existing?.title, url, provider.label);
  const projectName =
    normalizeProjectName(metadata?.projectName) ||
    existing?.projectName ||
    inferProjectNameFromTabTitle(provider, tab?.title, title);

  await upsertRecentChatCache(provider, [{
    url,
    title,
    projectName,
    lastUsedAt: Date.now(),
    source: "cache"
  }]);
}

function mergeRecentChatByUrl(mergedByUrl, entry) {
  if (!entry?.url) {
    return;
  }

  const existing = mergedByUrl.get(entry.url);
  if (!existing) {
    mergedByUrl.set(entry.url, entry);
    return;
  }

  const existingLastUsedAt = normalizeTimestamp(existing.lastUsedAt);
  const nextLastUsedAt = normalizeTimestamp(entry.lastUsedAt);
  const nextSource = normalizeRecentChatSource(entry.source);
  const shouldPreferNextTitle = nextSource === "sidebar" || nextSource === "tab" || !existing.title;

  mergedByUrl.set(entry.url, {
    ...existing,
    ...entry,
    title: shouldPreferNextTitle ? entry.title : existing.title,
    projectName: entry.projectName || existing.projectName || "",
    tabId: entry.tabId || existing.tabId,
    lastUsedAt: Math.max(existingLastUsedAt, nextLastUsedAt),
    orderIndex: mergeOrderIndex(existing.orderIndex, entry.orderIndex),
    source: pickMergedRecentChatSource(existing, entry)
  });
}

function mergeOrderIndex(existingOrderIndex, nextOrderIndex) {
  if (existingOrderIndex === null || existingOrderIndex === undefined) {
    return nextOrderIndex === null || nextOrderIndex === undefined ? null : nextOrderIndex;
  }
  if (nextOrderIndex === null || nextOrderIndex === undefined) {
    return existingOrderIndex;
  }
  return Math.min(existingOrderIndex, nextOrderIndex);
}

function pickMergedRecentChatSource(existing, entry) {
  if (entry?.source === "tab" || existing?.source === "tab" || entry?.tabId || existing?.tabId) {
    return "tab";
  }
  if (normalizeTimestamp(entry?.lastUsedAt) || normalizeTimestamp(existing?.lastUsedAt)) {
    return "cache";
  }
  if (entry?.source === "sidebar" || existing?.source === "sidebar") {
    return "sidebar";
  }
  return "cache";
}

function finalizeRecentChatSource(entry) {
  return {
    ...entry,
    source: pickMergedRecentChatSource(entry, {})
  };
}

function compareRecentChatEntries(a, b) {
  const aLastUsedAt = normalizeTimestamp(a?.lastUsedAt);
  const bLastUsedAt = normalizeTimestamp(b?.lastUsedAt);
  if (aLastUsedAt !== bLastUsedAt) {
    return bLastUsedAt - aLastUsedAt;
  }

  const aSourceRank = recentChatSourceRank(a?.source);
  const bSourceRank = recentChatSourceRank(b?.source);
  if (aSourceRank !== bSourceRank) {
    return aSourceRank - bSourceRank;
  }

  const aOrderIndex = Number.isInteger(a?.orderIndex) ? a.orderIndex : Number.MAX_SAFE_INTEGER;
  const bOrderIndex = Number.isInteger(b?.orderIndex) ? b.orderIndex : Number.MAX_SAFE_INTEGER;
  if (aOrderIndex !== bOrderIndex) {
    return aOrderIndex - bOrderIndex;
  }

  return String(a?.title || "").localeCompare(String(b?.title || ""));
}

function recentChatSourceRank(source) {
  if (source === "tab") {
    return 0;
  }
  if (source === "sidebar") {
    return 1;
  }
  return 2;
}

function stripRecentChatInternalFields(entry) {
  const cleanEntry = {
    id: entry.id,
    title: entry.title,
    url: entry.url,
    source: entry.source
  };
  if (entry.projectName) {
    cleanEntry.projectName = entry.projectName;
  }
  if (entry.lastUsedAt) {
    cleanEntry.lastUsedAt = entry.lastUsedAt;
  }
  if (entry.tabId) {
    cleanEntry.tabId = entry.tabId;
  }
  return cleanEntry;
}

async function findTargetTab(provider, sourceWindowId) {
  const tabs = await getProviderTabs(provider);
  const matchingTabs = tabs.filter((tab) => normalizeProviderUrl(provider, tab.url || ""));
  return pickPreferredTab(matchingTabs, sourceWindowId);
}

function pickPreferredTab(candidates, sourceWindowId) {
  if (!candidates.length) {
    return null;
  }

  const ranked = candidates.sort((a, b) => compareTabs(a, b, sourceWindowId));
  return ranked[0] || null;
}

function compareTabs(a, b, sourceWindowId) {
  const aSameWindow = typeof sourceWindowId === "number" && a.windowId === sourceWindowId ? 1 : 0;
  const bSameWindow = typeof sourceWindowId === "number" && b.windowId === sourceWindowId ? 1 : 0;
  if (aSameWindow !== bSameWindow) {
    return bSameWindow - aSameWindow;
  }

  const aActive = a.active ? 1 : 0;
  const bActive = b.active ? 1 : 0;
  if (aActive !== bActive) {
    return bActive - aActive;
  }

  const aLastAccessed = typeof a.lastAccessed === "number" ? a.lastAccessed : 0;
  const bLastAccessed = typeof b.lastAccessed === "number" ? b.lastAccessed : 0;
  return bLastAccessed - aLastAccessed;
}

function ensureUploadLimit(provider, tab) {
  const tabId = tab?.id;
  if (!tabId) {
    return {
      delivered: false,
      ok: false,
      code: "UPLOAD_DISPATCH_FAILED",
      message: `${provider.label} tab is unavailable.`
    };
  }

  const nextConversationKey = conversationKeyFromUrl(provider, tab?.url || "");
  const fallbackKey = `tab:${tabId}`;
  const effectiveKey = nextConversationKey || fallbackKey;

  const currentState = uploadStateByTabId.get(tabId);
  if (
    !currentState ||
    currentState.providerKey !== provider.key ||
    currentState.conversationKey !== effectiveKey
  ) {
    uploadStateByTabId.set(tabId, {
      providerKey: provider.key,
      conversationKey: effectiveKey,
      count: 0
    });
  }

  const state = uploadStateByTabId.get(tabId);
  if (!state) {
    return {
      delivered: false,
      ok: false,
      code: "UPLOAD_DISPATCH_FAILED",
      message: "Could not initialize upload state."
    };
  }

  if (state.count >= provider.maxFilesPerConversation) {
    return {
      delivered: false,
      ok: false,
      code: "PROVIDER_FILE_LIMIT_REACHED",
      message: `${provider.label} file limit reached (${provider.maxFilesPerConversation}). Open a new chat and continue.`,
      conversationKey: state.conversationKey
    };
  }

  return {
    delivered: false,
    ok: true,
    conversationKey: state.conversationKey
  };
}

function incrementUploadCount(tabId, providerKey, conversationKey) {
  if (!tabId) {
    return;
  }

  const state = uploadStateByTabId.get(tabId);
  if (
    !state ||
    state.providerKey !== providerKey ||
    state.conversationKey !== conversationKey
  ) {
    uploadStateByTabId.set(tabId, {
      providerKey,
      conversationKey: conversationKey || `tab:${tabId}`,
      count: 1
    });
    return;
  }

  state.count += 1;
}

function conversationKeyFromUrl(provider, urlValue) {
  const normalizedConversation = normalizeConversationUrlForChooser(provider, urlValue);
  if (normalizedConversation) {
    return normalizedConversation;
  }
  return normalizeProviderUrl(provider, urlValue);
}

function normalizeConversationUrlForChooser(provider, urlValue) {
  const normalized = normalizeProviderUrl(provider, urlValue);
  if (!normalized) {
    return "";
  }

  try {
    const parsed = new URL(normalized);

    if (provider.key === "chatgpt") {
      if (parsed.pathname.startsWith("/c/")) {
        return `${parsed.origin}${parsed.pathname}`;
      }
      return "";
    }

    if (provider.key === "claude") {
      if (parsed.pathname.startsWith("/chat/")) {
        return `${parsed.origin}${parsed.pathname}`;
      }
      return "";
    }

    if (provider.key === "gemini") {
      if (parsed.pathname.startsWith("/app/")) {
        return `${parsed.origin}${parsed.pathname}${parsed.search}`;
      }
      return "";
    }

    return "";
  } catch (_error) {
    return "";
  }
}

function normalizeProviderUrl(provider, urlValue) {
  if (!urlValue || !provider.urlRe.test(urlValue)) {
    return "";
  }

  try {
    const parsed = new URL(urlValue);
    return `${parsed.origin}${parsed.pathname}${parsed.search}`;
  } catch (_error) {
    return "";
  }
}

function isValidHttpsUrl(urlValue) {
  try {
    const parsed = new URL(String(urlValue || ""));
    return parsed.protocol === "https:";
  } catch (_error) {
    return false;
  }
}

function mapTelegramSendFailureMessage(status, description) {
  const text = String(description || "").trim();
  const lower = text.toLowerCase();

  if (
    status === 400 ||
    lower.includes("chat not found") ||
    lower.includes("chat_id is empty") ||
    lower.includes("peer_id_invalid")
  ) {
    return "Telegram 400: invalid chat_id for this bot. Send a message to the bot, then fetch chat_id using this same token in getUpdates.";
  }

  if (
    status === 403 ||
    lower.includes("forbidden") ||
    lower.includes("bot was blocked by the user") ||
    lower.includes("not enough rights")
  ) {
    return "Telegram 403: bot blocked or missing chat permissions. Start/unblock the bot and ensure it has permission in the target chat/group/channel.";
  }

  if (text) {
    return `Telegram rejected the upload: ${text}`;
  }

  return status ? `Telegram request failed (${status}).` : "Telegram request failed.";
}

function normalizeInteger(value, fallback, min, max) {
  const parsed = Number(value);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }
  return Math.min(max, Math.max(min, Math.floor(parsed)));
}

function isUnsupportedSourcePageError(error) {
  const message = String(error?.message || error || "").toLowerCase();
  return (
    message.includes("cannot access a chrome:// url") ||
    message.includes("cannot access contents of url") ||
    message.includes("extensions gallery cannot be scripted") ||
    message.includes("cannot access a privileged url")
  );
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

const answerReadLocks = new Map();
async function readAnswerSnapshots(tabId) {
  const results = await chrome.scripting.executeScript({target:{tabId,allFrames:true},files:["answer_reader.js"]});
  return results.filter(item=>item.result).map(item=>({frameId:item.frameId,...item.result}));
}
async function pollAnswerState(sourceTabId) {
  if(!sourceTabId)return null;
  if(answerReadLocks.has(sourceTabId))return answerReadLocks.get(sourceTabId);
  const task=refreshAnswerState(sourceTabId).finally(()=>answerReadLocks.delete(sourceTabId));
  answerReadLocks.set(sourceTabId,task);return task;
}
async function refreshAnswerState(sourceTabId) {
  const key=`answerState_${sourceTabId}`, jobKey=`answerJob_${sourceTabId}`;
  const data=await chrome.storage.local.get([key,jobKey]);
  const job=data[jobKey];
  if(!job||job.done)return data[key]||null;
  let frames;
  try {frames=await readAnswerSnapshots(job.targetTabId);}
  catch(error){
    await notifySourceTab(sourceTabId,{code:"READER_ERROR",message:"Could not read the ChatGPT tab: "+error.message});
    return (await chrome.storage.local.get(key))[key];
  }
  const current=frames.find(frame=>{
    const before=job.baseline.find(b=>b.frameId===frame.frameId)||{text:"",count:0};
    return frame.text&&(frame.text!==before.text||frame.count>before.count);
  });
  if(Date.now()-job.startedAt>300000){
    job.done=true;
    await notifySourceTab(sourceTabId,{code:"ANSWER_TIMEOUT",message:"No final reply detected. Refresh ChatGPT, then retry the screenshot."});
    await chrome.storage.local.set({[jobKey]:job});
    return (await chrome.storage.local.get(key))[key];
  }
  if(current){
    if(current.text!==job.lastText){job.lastText=current.text;job.stableSince=Date.now();}
    const ready=!current.busy&&Date.now()-job.stableSince>=3500&&(
      current.complete===true || (Date.now()-job.stableSince>=10000&&current.method!=="progress")
    );
    const status={answer:current.text,code:ready?"ANSWER_READY":"ANSWER_STREAMING",message:ready?"Reply ready":"ChatGPT is replying…",delivered:true};
    await notifySourceTab(sourceTabId,status);
    await chrome.storage.local.set({latestAnswer:status});
    if(ready){
      job.done=true;
      try { await copyAnswerAutomatically(current.text); status.message="Reply ready · copied to clipboard"; }
      catch(error){status.message="Reply ready · automatic copy failed: "+error.message;}
      await notifySourceTab(sourceTabId,status);
      await chrome.storage.local.set({latestAnswer:status});
    }
  } else if(Date.now()-job.startedAt>300000){
    job.done=true;
    await notifySourceTab(sourceTabId,{code:"ANSWER_TIMEOUT",message:"No readable reply detected. Refresh ChatGPT, then retry the screenshot."});
  } else if(Date.now()-job.startedAt>15000){
    await notifySourceTab(sourceTabId,{code:"WAITING",message:"Still checking ChatGPT. " + frames.map(f=>`Frame ${f.frameId}: ${f.count} reply blocks, ${f.markdownCount||0} text blocks, ${f.text?.length||0} reply characters. ${f.pageState||""}`).join(" ") + " If the reply is already finished, send me these numbers so I can identify the page layout."});
  }
  await chrome.storage.local.set({[jobKey]:job});
  return (await chrome.storage.local.get(key))[key];
}

let clipboardDocumentPromise;
async function copyAnswerAutomatically(text) {
  if(!clipboardDocumentPromise) clipboardDocumentPromise=(async()=>{
    if(!await chrome.offscreen.hasDocument()) await chrome.offscreen.createDocument({url:"offscreen.html",reasons:["CLIPBOARD"],justification:"Automatically copy the completed ChatGPT reply requested by the user."});
  })().finally(()=>{clipboardDocumentPromise=null;});
  await clipboardDocumentPromise;
  const result=await chrome.runtime.sendMessage({target:"clipboard",type:"COPY_ANSWER",text});
  if(!result?.ok)throw new Error(result?.error||"No clipboard confirmation");
}
