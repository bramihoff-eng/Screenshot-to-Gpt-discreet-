(() => {
  const SNIP_SCRIPT_VERSION = "2026-09-28-r9";

  if (window.__snipToAiVersion === SNIP_SCRIPT_VERSION) {
    return;
  }

  if (typeof window.__snipToAiDispose === "function") {
    try {
      window.__snipToAiDispose();
    } catch (_error) {
      // Best-effort cleanup when replacing an older injected script.
    }
  }

  window.__snipToAiLoaded = true;
  window.__snipToAiVersion = SNIP_SCRIPT_VERSION;

  const PROVIDER_OPTIONS = [
    { key: "chatgpt", label: "ChatGPT" },
    { key: "claude", label: "Claude" },
    { key: "gemini", label: "Gemini" },
    { key: "telegram_claw", label: "OpenClaw/Telegram" }
  ];
  const PROVIDER_SET = new Set(PROVIDER_OPTIONS.map((value) => value.key));

  let overlay = null;
  let selectionBox = null;
  let infoBox = null;
  let routeInfoBox = null;
  let startX = 0;
  let startY = 0;
  let endX = 0;
  let endY = 0;
  let isSelecting = false;
  let selectionMouseButton = 0;
  let selectionStartMode = "quick";
  let suppressStatusToastUntil = 0;
  let activeChooserCleanup = null;

  function onRuntimeMessage(message) {
    if (message?.type === "START_SNIP_SELECTION") {
      startSelection(message?.startMode);
    }

    if (message?.type === "SNIP_STATUS") {
      showAnswerWidget(message.answer, "ChatGPT", message.message, message.code);

    }
  }

  chrome.runtime.onMessage.addListener(onRuntimeMessage);

  window.__snipToAiDispose = () => {
    chrome.runtime.onMessage.removeListener(onRuntimeMessage);
    clearInterval(answerPollTimer);
    cleanup();
    if (typeof activeChooserCleanup === "function") {
      activeChooserCleanup();
      activeChooserCleanup = null;
    }
  };

  function startSelection(startMode) {
    cleanup();
    selectionStartMode = normalizeStartMode(startMode);

    overlay = document.createElement("div");
    overlay.style.position = "fixed";
    overlay.style.left = "0";
    overlay.style.top = "0";
    overlay.style.width = "100vw";
    overlay.style.height = "100vh";
    overlay.style.zIndex = "2147483647";
    overlay.style.cursor = "crosshair";
    overlay.style.background = "rgba(0, 0, 0, 0.22)";
    overlay.style.userSelect = "none";

    selectionBox = document.createElement("div");
    selectionBox.style.position = "fixed";
    selectionBox.style.border = "2px solid #ffffff";
    selectionBox.style.boxShadow = "0 0 0 1px rgba(0, 0, 0, 0.45)";
    selectionBox.style.background = "rgba(255, 255, 255, 0.08)";
    selectionBox.style.display = "none";

    infoBox = document.createElement("div");
    infoBox.style.position = "fixed";
    infoBox.style.left = "12px";
    infoBox.style.top = "12px";
    infoBox.style.padding = "8px 10px";
    infoBox.style.fontFamily = "ui-monospace, SFMono-Regular, Menlo, monospace";
    infoBox.style.fontSize = "12px";
    infoBox.style.color = "#fff";
    infoBox.style.background = "rgba(0, 0, 0, 0.55)";
    infoBox.style.borderRadius = "8px";
    infoBox.textContent = "Left drag: quick send. Right drag or hold Option/Alt: choose chat. Esc cancels.";

    routeInfoBox = document.createElement("div");
    routeInfoBox.style.position = "fixed";
    routeInfoBox.style.right = "12px";
    routeInfoBox.style.top = "12px";
    routeInfoBox.style.padding = "8px 10px";
    routeInfoBox.style.fontFamily = "ui-monospace, SFMono-Regular, Menlo, monospace";
    routeInfoBox.style.fontSize = "12px";
    routeInfoBox.style.color = "#fff";
    routeInfoBox.style.background = "rgba(0, 0, 0, 0.55)";
    routeInfoBox.style.borderRadius = "8px";
    routeInfoBox.style.maxWidth = "min(52vw, 620px)";
    routeInfoBox.style.textAlign = "right";
    routeInfoBox.textContent = "Destination: loading...";

    overlay.appendChild(selectionBox);
    overlay.appendChild(infoBox);
    overlay.appendChild(routeInfoBox);
    document.documentElement.appendChild(overlay);
    void refreshRouteInfoBox(selectionStartMode);

    overlay.addEventListener("pointerdown", onPointerDown);
    overlay.addEventListener("pointermove", onPointerMove);
    overlay.addEventListener("pointerup", onPointerUp);
    overlay.addEventListener("contextmenu", onContextMenu);
    window.addEventListener("keydown", onKeyDown, true);
  }

  function onPointerDown(event) {
    selectionMouseButton = event.pointerType === "mouse" ? event.button : 0;
    isSelecting = true;
    startX = event.clientX;
    startY = event.clientY;
    endX = event.clientX;
    endY = event.clientY;
    selectionBox.style.display = "block";
    updateSelectionBox();
  }

  function onPointerMove(event) {
    if (!isSelecting) {
      return;
    }
    endX = event.clientX;
    endY = event.clientY;
    updateSelectionBox();
  }

  async function onPointerUp(event) {
    if (!isSelecting) {
      return;
    }
    endX = event.clientX;
    endY = event.clientY;
    isSelecting = false;
    const triggerMouseButton = selectionMouseButton;
    const chooseChatRequested = selectionStartMode === "choose" || triggerMouseButton === 2 || Boolean(event.altKey);

    const rect = normalizeRect(startX, startY, endX, endY);
    cleanup();

    if (rect.width < 8 || rect.height < 8) {
      showToast("Selection too small");
      return;
    }

    try {
      const captureResponse = await sendMessageWithTimeout(
        { type: "CAPTURE_VISIBLE_TAB" },
        9000,
        {
          ok: false,
          code: "CAPTURE_FAILED",
          message: "Capture request timed out."
        }
      );
      if (!captureResponse?.ok || !captureResponse.dataUrl) {
        throw new Error(captureResponse?.message || statusMessageFromCode(captureResponse?.code));
      }

      const croppedBlob = await cropImage(captureResponse.dataUrl, rect);
      const imageDataUrl = await blobToDataUrl(croppedBlob);
      let clipboardCopied = false;

      try {
        await copyToClipboard(croppedBlob);
        clipboardCopied = true;
      } catch (clipboardError) {
        console.warn("Could not copy image to clipboard:", clipboardError);
      }

      const destination = { provider: "chatgpt" };
      showAnswerWidget("", "ChatGPT", "Sending screenshot…");
      startAnswerPolling();

      suppressStatusToastUntil = Date.now() + 3000;
      let routeResponse = await sendMessageWithTimeout(
        {
          type: "ROUTE_IMAGE_TO_AI",
          imageDataUrl,
          watchAnswer: true,

          ...destination
        },
        60000,
        {
          ok: false,
          delivered: false,
          code: "UPLOAD_DISPATCH_FAILED",
          message: "Upload request timed out."
        }
      );

      if (routeResponse?.code === "TELEGRAM_NO_LAST_RECIPIENT") {
        const telegramDestination = await chooseTargetChat({
          initialProvider: "telegram_claw",
          allowText: false
        });
        if (telegramDestination?.cancelSelection) {
          showToast("Capture canceled");
          return;
        }

        routeResponse = await sendMessageWithTimeout(
          {
            type: "ROUTE_IMAGE_TO_AI",
            imageDataUrl,
            ...telegramDestination
          },
          32000,
          {
            ok: false,
            delivered: false,
            code: "UPLOAD_DISPATCH_FAILED",
            message: "Upload request timed out."
          }
        );
      }

      if (routeResponse?.ok && routeResponse.delivered) {
        if (routeResponse?.textRequested && routeResponse?.textSent === false) {
          showToast(
            clipboardCopied
              ? `Copied. ${routeResponse.message || "Image attached, text not sent automatically."}`
              : routeResponse.message || "Image attached, text not sent automatically."
          );
          return;
        }
        showToast(routeResponse.watchAnswer
          ? "Sent. Click the gray ChatGPT box to read the reply."
          : clipboardCopied ? "Copied + uploaded" : "Uploaded");
        return;
      }

      const statusText = statusMessageFromCode(routeResponse?.code, routeResponse?.message);
      showToast(clipboardCopied ? `Copied only: ${statusText}` : statusText);
    } catch (error) {
      console.error("Snip to AI failed:", error);
      showToast(error?.message || "Capture failed");
    }
  }

  function onKeyDown(event) {
    if (event.key !== "Escape") {
      return;
    }
    cleanup();
    showToast("Capture canceled");
  }

  function onContextMenu(event) {
    event.preventDefault();
  }

  function updateSelectionBox() {
    const rect = normalizeRect(startX, startY, endX, endY);
    selectionBox.style.left = `${rect.x}px`;
    selectionBox.style.top = `${rect.y}px`;
    selectionBox.style.width = `${rect.width}px`;
    selectionBox.style.height = `${rect.height}px`;
  }

  function normalizeRect(x1, y1, x2, y2) {
    const x = Math.min(x1, x2);
    const y = Math.min(y1, y2);
    const width = Math.abs(x2 - x1);
    const height = Math.abs(y2 - y1);
    return { x, y, width, height };
  }

  async function cropImage(dataUrl, rect) {
    const image = await loadImage(dataUrl);

    const scaleX = image.width / window.innerWidth;
    const scaleY = image.height / window.innerHeight;

    const sx = Math.round(rect.x * scaleX);
    const sy = Math.round(rect.y * scaleY);
    const sWidth = Math.max(1, Math.round(rect.width * scaleX));
    const sHeight = Math.max(1, Math.round(rect.height * scaleY));

    const canvas = document.createElement("canvas");
    canvas.width = sWidth;
    canvas.height = sHeight;

    const ctx = canvas.getContext("2d");
    if (!ctx) {
      throw new Error("Could not get 2D canvas context");
    }
    ctx.drawImage(image, sx, sy, sWidth, sHeight, 0, 0, sWidth, sHeight);

    return new Promise((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error("Could not create cropped image"));
          return;
        }
        resolve(blob);
      }, "image/png");
    });
  }

  function loadImage(dataUrl) {
    return new Promise((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = () => reject(new Error("Could not load captured image"));
      image.src = dataUrl;
    });
  }

  async function copyToClipboard(blob) {
    if (!navigator.clipboard?.write) {
      throw new Error("Clipboard write API unavailable");
    }

    const item = new ClipboardItem({ [blob.type]: blob });
    await navigator.clipboard.write([item]);
  }

  function blobToDataUrl(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error("Failed to convert image"));
      reader.readAsDataURL(blob);
    });
  }

  function cleanup() {
    window.removeEventListener("keydown", onKeyDown, true);
    if (overlay) {
      overlay.removeEventListener("pointerdown", onPointerDown);
      overlay.removeEventListener("pointermove", onPointerMove);
      overlay.removeEventListener("pointerup", onPointerUp);
      overlay.removeEventListener("contextmenu", onContextMenu);
      overlay.remove();
      overlay = null;
    }
    selectionBox = null;
    infoBox = null;
    routeInfoBox = null;
    isSelecting = false;
    selectionMouseButton = 0;
    selectionStartMode = "quick";
  }

  function normalizeStartMode(value) {
    return value === "choose" ? "choose" : "quick";
  }

  function statusMessageFromCode(code, fallbackMessage) {
    if (fallbackMessage) {
      return fallbackMessage;
    }

    switch (code) {
      case "TARGET_TAB_NOT_FOUND":
        return "Target AI tab not found.";
      case "UPLOAD_INPUT_NOT_FOUND":
        return "Upload input not found on provider page.";
      case "UPLOAD_DISPATCH_FAILED":
        return "Upload failed on provider tab.";
      case "PROVIDER_NOT_READY":
        return "Provider is not ready for uploads yet.";
      case "SCRIPT_INJECTION_FAILED":
        return "Could not access provider tab.";
      case "CAPTURE_FAILED":
        return "Capture failed.";
      case "UNSUPPORTED_SOURCE_PAGE":
        return "Snip is unavailable on this page.";
      case "PROVIDER_FILE_LIMIT_REACHED":
        return "Provider file limit reached. Open a new chat tab.";
      case "TELEGRAM_RECIPIENT_NOT_FOUND":
        return "OpenClaw/Telegram connection not found.";
      case "TELEGRAM_NO_LAST_RECIPIENT":
        return "No last OpenClaw/Telegram connection. Pick one.";
      case "TELEGRAM_BOT_TOKEN_MISSING":
        return "Telegram bot token missing in options.";
      case "TELEGRAM_SEND_FAILED":
        return "Telegram send failed.";
      case "WEBHOOK_SEND_FAILED":
        return "Webhook send failed.";
      default:
        return "Upload failed.";
    }
  }

  function chooseTargetChat(options = {}) {
    return new Promise((resolve) => {
      const allowText = options.allowText !== false;
      let settled = false;
      let currentProvider = typeof options.initialProvider === "string"
        ? normalizeProvider(options.initialProvider)
        : "";
      let selectedDestination = null;
      let selectedButton = null;
      let chooserItems = [];
      let selectedIndex = -1;
      let loadToken = 0;

      const closeChooser = () => {
        window.removeEventListener("keydown", onModalKeyDown, true);
        document.removeEventListener("click", onChooserDocumentClick, true);
        if (modalOverlay.isConnected) {
          modalOverlay.remove();
        }
        if (activeChooserCleanup === closeChooser) {
          activeChooserCleanup = null;
        }
      };

      const done = (result) => {
        if (settled) {
          return;
        }
        settled = true;
        closeChooser();
        resolve(result);
      };

      const modalOverlay = document.createElement("div");
      modalOverlay.style.position = "fixed";
      modalOverlay.style.left = "0";
      modalOverlay.style.top = "0";
      modalOverlay.style.width = "100vw";
      modalOverlay.style.height = "100vh";
      modalOverlay.style.background = "rgba(8, 8, 10, 0.45)";
      modalOverlay.style.zIndex = "2147483647";
      modalOverlay.style.display = "flex";
      modalOverlay.style.alignItems = "center";
      modalOverlay.style.justifyContent = "center";

      const panel = document.createElement("div");
      panel.style.width = "min(560px, calc(100vw - 24px))";
      panel.style.maxHeight = "min(78vh, 620px)";
      panel.style.overflow = "auto";
      panel.style.background = "#fff";
      panel.style.color = "#111";
      panel.style.borderRadius = "20px";
      panel.style.boxShadow = "0 20px 50px rgba(0, 0, 0, 0.35)";
      panel.style.padding = "14px";
      panel.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";

      const headerRow = document.createElement("div");
      headerRow.style.display = "flex";
      headerRow.style.gap = "10px";
      headerRow.style.justifyContent = "space-between";
      headerRow.style.alignItems = "flex-start";

      const titleWrap = document.createElement("div");
      const title = document.createElement("div");
      title.textContent = "Choose destination";
      title.style.fontSize = "14px";
      title.style.fontWeight = "700";
      const hint = document.createElement("div");
      hint.textContent = "Select a recent chat. You can switch provider here.";
      hint.style.fontSize = "12px";
      hint.style.color = "#4b4b4b";
      hint.style.marginTop = "4px";
      titleWrap.appendChild(title);
      titleWrap.appendChild(hint);

      const providerPicker = document.createElement("div");
      providerPicker.style.position = "relative";
      providerPicker.style.minWidth = "190px";
      providerPicker.style.visibility = "hidden";

      const providerTrigger = document.createElement("button");
      providerTrigger.type = "button";
      providerTrigger.setAttribute("aria-haspopup", "listbox");
      providerTrigger.setAttribute("aria-expanded", "false");
      providerTrigger.style.width = "100%";
      providerTrigger.style.display = "flex";
      providerTrigger.style.alignItems = "center";
      providerTrigger.style.justifyContent = "space-between";
      providerTrigger.style.gap = "10px";
      providerTrigger.style.padding = "10px 12px";
      providerTrigger.style.border = "1px solid #dfe4eb";
      providerTrigger.style.borderRadius = "16px";
      providerTrigger.style.background = "#fff";
      providerTrigger.style.color = "#15171c";
      providerTrigger.style.fontSize = "12px";
      providerTrigger.style.fontWeight = "650";
      providerTrigger.style.cursor = "pointer";
      providerTrigger.style.boxShadow = "0 1px 2px rgba(27, 32, 44, 0.06)";

      const providerValue = document.createElement("span");
      const providerChevron = document.createElement("span");
      providerChevron.style.width = "8px";
      providerChevron.style.height = "8px";
      providerChevron.style.borderRight = "2px solid #5f6876";
      providerChevron.style.borderBottom = "2px solid #5f6876";
      providerChevron.style.transform = "rotate(45deg) translateY(-2px)";
      providerChevron.style.transition = "transform 140ms ease";
      providerTrigger.appendChild(providerValue);
      providerTrigger.appendChild(providerChevron);

      const providerMenu = document.createElement("div");
      providerMenu.setAttribute("role", "listbox");
      providerMenu.setAttribute("aria-label", "Destination provider");
      providerMenu.style.position = "absolute";
      providerMenu.style.top = "calc(100% + 7px)";
      providerMenu.style.right = "0";
      providerMenu.style.zIndex = "2";
      providerMenu.style.width = "100%";
      providerMenu.style.display = "none";
      providerMenu.style.gap = "4px";
      providerMenu.style.padding = "6px";
      providerMenu.style.border = "1px solid #dfe4eb";
      providerMenu.style.borderRadius = "18px";
      providerMenu.style.background = "rgba(255, 255, 255, 0.98)";
      providerMenu.style.boxShadow = "0 18px 40px rgba(27, 32, 44, 0.16)";

      const providerOptionButtons = PROVIDER_OPTIONS.map((providerOption) => {
        const optionButton = document.createElement("button");
        optionButton.type = "button";
        optionButton.setAttribute("role", "option");
        optionButton.dataset.value = providerOption.key;
        optionButton.textContent = providerOption.label;
        optionButton.style.width = "100%";
        optionButton.style.border = "0";
        optionButton.style.borderRadius = "13px";
        optionButton.style.background = "transparent";
        optionButton.style.padding = "9px 11px";
        optionButton.style.color = "#15171c";
        optionButton.style.fontSize = "12px";
        optionButton.style.fontWeight = "600";
        optionButton.style.textAlign = "left";
        optionButton.style.cursor = "pointer";
        providerMenu.appendChild(optionButton);
        return optionButton;
      });
      providerPicker.appendChild(providerTrigger);
      providerPicker.appendChild(providerMenu);

      headerRow.appendChild(titleWrap);
      headerRow.appendChild(providerPicker);

      const list = document.createElement("div");
      list.style.display = "grid";
      list.style.gap = "8px";
      list.style.marginTop = "12px";

      const helperText = document.createElement("div");
      helperText.style.fontSize = "12px";
      helperText.style.color = "#666";
      helperText.style.marginTop = "8px";

      const footerRow = document.createElement("div");
      footerRow.style.marginTop = "12px";
      footerRow.style.display = "grid";
      footerRow.style.gap = "12px";

      const textControls = document.createElement("div");
      textControls.style.display = "grid";
      textControls.style.gap = "8px";
      textControls.style.minWidth = "0";

      const addTextLabel = document.createElement("label");
      addTextLabel.style.display = "inline-flex";
      addTextLabel.style.alignItems = "center";
      addTextLabel.style.gap = "6px";
      addTextLabel.style.fontSize = "12px";
      addTextLabel.style.color = "#333";
      const addTextCheckbox = document.createElement("input");
      addTextCheckbox.type = "checkbox";
      addTextLabel.appendChild(addTextCheckbox);
      addTextLabel.appendChild(document.createTextNode("Add text"));

      const textArea = document.createElement("textarea");
      textArea.placeholder = "Optional prompt text...";
      textArea.rows = 3;
      textArea.maxLength = 2000;
      textArea.style.display = "none";
      textArea.style.resize = "vertical";
      textArea.style.width = "100%";
      textArea.style.border = "1px solid #dfe4eb";
      textArea.style.borderRadius = "16px";
      textArea.style.padding = "12px";
      textArea.style.fontSize = "12px";
      textArea.style.boxShadow = "inset 0 1px 0 rgba(27, 32, 44, 0.02)";

      addTextCheckbox.addEventListener("change", () => {
        textArea.style.display = addTextCheckbox.checked ? "block" : "none";
        if (!addTextCheckbox.checked) {
          textArea.value = "";
        }
      });

      textControls.appendChild(addTextLabel);
      textControls.appendChild(textArea);
      textControls.style.display = allowText ? "grid" : "none";

      const actionRow = document.createElement("div");
      actionRow.style.display = "flex";
      actionRow.style.gap = "8px";
      actionRow.style.justifyContent = "flex-end";

      const closeButton = document.createElement("button");
      closeButton.type = "button";
      closeButton.textContent = "Cancel";
      closeButton.style.border = "1px solid #dfe4eb";
      closeButton.style.background = "#f7f8fa";
      closeButton.style.color = "#222";
      closeButton.style.padding = "10px 14px";
      closeButton.style.borderRadius = "14px";
      closeButton.style.cursor = "pointer";
      closeButton.style.fontWeight = "650";
      closeButton.addEventListener("click", () => {
        done({ cancelSelection: true });
      });

      const sendButton = document.createElement("button");
      sendButton.type = "button";
      sendButton.textContent = "Send";
      sendButton.style.border = "1px solid #0a65cc";
      sendButton.style.background = "#0a65cc";
      sendButton.style.color = "#fff";
      sendButton.style.padding = "10px 14px";
      sendButton.style.borderRadius = "14px";
      sendButton.style.cursor = "pointer";
      sendButton.style.fontWeight = "650";
      sendButton.style.boxShadow = "0 10px 24px rgba(10, 101, 204, 0.2)";
      sendButton.disabled = true;
      sendButton.style.opacity = "0.65";
      sendButton.addEventListener("click", () => {
        submitSelectedDestination();
      });

      function submitSelectedDestination() {
        if (!selectedDestination) {
          helperText.textContent = "Select a destination first.";
          return;
        }

        done({
          provider: currentProvider,
          promptText: allowText && addTextCheckbox.checked ? String(textArea.value || "").trim() : "",
          ...selectedDestination
        });
      }

      actionRow.appendChild(closeButton);
      actionRow.appendChild(sendButton);
      footerRow.appendChild(textControls);
      footerRow.appendChild(actionRow);

      panel.appendChild(headerRow);
      panel.appendChild(list);
      panel.appendChild(helperText);
      panel.appendChild(footerRow);
      modalOverlay.appendChild(panel);
      document.documentElement.appendChild(modalOverlay);

      const setSelection = (button, destination) => {
        if (selectedButton) {
          setChooserButtonSelected(selectedButton, false);
        }
        selectedButton = button;
        selectedDestination = destination;
        selectedIndex = chooserItems.findIndex((item) => item.button === button);
        setChooserButtonSelected(button, true);
        sendButton.disabled = false;
        sendButton.style.opacity = "1";
      };

      const moveSelection = (nextIndex) => {
        if (!chooserItems.length) {
          helperText.textContent = "Select a destination first.";
          return;
        }

        const wrappedIndex = (nextIndex + chooserItems.length) % chooserItems.length;
        const item = chooserItems[wrappedIndex];
        setSelection(item.button, item.destination);
        item.button.focus({ preventScroll: true });
        item.button.scrollIntoView({ block: "nearest" });
      };

      const renderChoices = (providerLabel, chats, metadata = {}) => {
        list.innerHTML = "";
        helperText.textContent = "";
        selectedDestination = null;
        selectedButton = null;
        chooserItems = [];
        selectedIndex = -1;
        sendButton.disabled = true;
        sendButton.style.opacity = "0.65";

        const allowNewTarget = normalizeProvider(currentProvider) !== "telegram_claw";
        const safeChats = Array.isArray(chats) ? chats.slice(0, 8) : [];
        const choiceItems = [];

        for (const chat of safeChats) {
          choiceItems.push({
            title: formatChatTitle(chat),
            subtitle: String(chat?.subtitle || "") || (chat?.url ? simplifyChatUrl(chat.url) : ""),
            projectName: String(chat?.projectName || "").replace(/\s+/g, " ").trim(),
            destination: {
              targetTabId: Number.isInteger(chat?.tabId) ? chat.tabId : undefined,
              targetChatUrl: chat?.url || undefined,
              targetRecipientId: chat?.targetRecipientId || undefined,
              forceNewChat: false
            }
          });
        }

        if (choiceItems.length < 1) {
          const empty = document.createElement("div");
          empty.textContent = currentProvider === "telegram_claw"
            ? "No OpenClaw/Telegram connections found. Add one in options."
            : "No recent chats found.";
          empty.style.fontSize = "12px";
          empty.style.color = "#666";
          empty.style.padding = "6px 2px";
          list.appendChild(empty);
          helperText.textContent = currentProvider === "telegram_claw"
            ? "Tip: open extension options to create or enable a connection."
            : metadata.scrapeOk === false
              ? `Could not read recent ${providerLabel} chats from the open tab. Choose New chat only if that is what you want.`
              : `No recent ${providerLabel} chats found. Choose New chat if that is what you want.`;
        }

        for (const item of choiceItems) {
          const button = createChooserButton(item.title, item.subtitle, item.projectName);
          button.addEventListener("click", () => {
            setSelection(button, item.destination);
          });
          button.addEventListener("dblclick", () => {
            setSelection(button, item.destination);
            submitSelectedDestination();
          });
          chooserItems.push({ button, destination: item.destination });
          list.appendChild(button);
        }

        if (allowNewTarget) {
          const newChatDestination = { forceNewChat: true };
          const newChatButton = createChooserButton("New chat", "Open a fresh chat and send screenshot");
          newChatButton.addEventListener("click", () => {
            setSelection(newChatButton, newChatDestination);
          });
          newChatButton.addEventListener("dblclick", () => {
            setSelection(newChatButton, newChatDestination);
            submitSelectedDestination();
          });
          chooserItems.push({ button: newChatButton, destination: newChatDestination });
          list.appendChild(newChatButton);
          if (choiceItems.length < 1) {
            setSelection(newChatButton, newChatDestination);
            helperText.textContent = metadata.providerTabCount > 0
              ? `No recent ${providerLabel} chats found. New chat is selected.`
              : `No saved ${providerLabel} chats yet. New chat is selected.`;
          }
        }
      };

      const loadChatsForProvider = async () => {
        const token = ++loadToken;
        helperText.textContent = "Loading chats...";
        list.innerHTML = "";
        selectedDestination = null;
        selectedButton = null;
        chooserItems = [];
        selectedIndex = -1;
        sendButton.disabled = true;
        sendButton.style.opacity = "0.65";

        const request = {
          type: "GET_RECENT_CHATS",
          limit: 8
        };
        if (currentProvider) {
          request.provider = currentProvider;
        }

        const response = await sendMessageWithTimeout(
          request,
          25000,
          {
            ok: false,
            provider: normalizeProvider(currentProvider || "chatgpt"),
            providerLabel: providerLabelFor(normalizeProvider(currentProvider || "chatgpt")),
            chats: []
          }
        );

        if (token !== loadToken) {
          return;
        }

        const responseProvider = normalizeProvider(response?.provider || currentProvider);
        currentProvider = responseProvider;
        setProviderMenuValue(responseProvider);
        providerPicker.style.visibility = "visible";
        renderChoices(
          String(response?.providerLabel || providerLabelFor(responseProvider)),
          Array.isArray(response?.chats) ? response.chats : [],
          {
            scrapeOk: response?.scrapeOk,
            providerTabCount: response?.providerTabCount
          }
        );
        if (response?.ok === false && response?.message) {
          helperText.textContent = response.message;
        }
      };

      modalOverlay.addEventListener("click", (event) => {
        if (event.target === modalOverlay) {
          done({ cancelSelection: true });
        }
      });

      function onModalKeyDown(event) {
        if (providerPicker.contains(event.target) && event.key !== "Escape") {
          return;
        }

        if (event.target === textArea && event.key === "Enter" && event.shiftKey) {
          return;
        }

        if (event.key === "Escape") {
          event.stopPropagation();
          event.preventDefault();
          if (providerMenu.style.display !== "none") {
            setProviderMenuOpen(false);
            providerTrigger.focus();
            return;
          }
          done({ cancelSelection: true });
          return;
        }

        if (event.key === "ArrowDown") {
          event.stopPropagation();
          event.preventDefault();
          moveSelection(selectedIndex < 0 ? 0 : selectedIndex + 1);
          return;
        }

        if (event.key === "ArrowUp") {
          event.stopPropagation();
          event.preventDefault();
          moveSelection(selectedIndex < 0 ? chooserItems.length - 1 : selectedIndex - 1);
          return;
        }

        if (event.key === "Home") {
          event.stopPropagation();
          event.preventDefault();
          moveSelection(0);
          return;
        }

        if (event.key === "End") {
          event.stopPropagation();
          event.preventDefault();
          moveSelection(chooserItems.length - 1);
          return;
        }

        if (event.key !== "Enter") {
          return;
        }

        event.stopPropagation();
        event.preventDefault();
        submitSelectedDestination();
      }

      window.addEventListener("keydown", onModalKeyDown, true);
      activeChooserCleanup = closeChooser;
      void initializeProviderAndLoadChats();

      async function initializeProviderAndLoadChats() {
        if (!currentProvider) {
          const providerResponse = await sendMessageWithTimeout(
            { type: "GET_SELECTED_PROVIDER" },
            2000,
            { ok: false, provider: "chatgpt" }
          );
          currentProvider = normalizeProvider(providerResponse?.provider);
        }
        setProviderMenuValue(currentProvider);
        providerPicker.style.visibility = "visible";
        await loadChatsForProvider();
      }

      providerTrigger.addEventListener("click", () => {
        setProviderMenuOpen(providerMenu.style.display === "none");
      });

      providerTrigger.addEventListener("keydown", (event) => {
        if (event.key !== "ArrowDown" && event.key !== "ArrowUp") {
          return;
        }
        event.preventDefault();
        setProviderMenuOpen(true);
        focusProviderMenuOption(event.key === "ArrowDown" ? 0 : providerOptionButtons.length - 1);
      });

      providerOptionButtons.forEach((optionButton, index) => {
        optionButton.addEventListener("click", () => {
          void chooseProvider(optionButton.dataset.value);
        });
        optionButton.addEventListener("mouseenter", () => {
          focusProviderMenuOption(index);
        });
        optionButton.addEventListener("keydown", (event) => {
          if (event.key === "ArrowDown") {
            event.preventDefault();
            focusProviderMenuOption(index + 1);
          } else if (event.key === "ArrowUp") {
            event.preventDefault();
            focusProviderMenuOption(index - 1);
          } else if (event.key === "Home") {
            event.preventDefault();
            focusProviderMenuOption(0);
          } else if (event.key === "End") {
            event.preventDefault();
            focusProviderMenuOption(providerOptionButtons.length - 1);
          } else if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            void chooseProvider(optionButton.dataset.value);
          } else if (event.key === "Escape") {
            event.preventDefault();
            setProviderMenuOpen(false);
            providerTrigger.focus();
          }
        });
      });

      document.addEventListener("click", onChooserDocumentClick, true);

      function onChooserDocumentClick(event) {
        if (!providerPicker.contains(event.target)) {
          setProviderMenuOpen(false);
        }
      }

      async function chooseProvider(providerValueKey) {
        currentProvider = normalizeProvider(providerValueKey);
        setProviderMenuValue(currentProvider);
        setProviderMenuOpen(false);
        try {
          await sendMessageWithTimeout(
            {
              type: "SET_SELECTED_PROVIDER",
              provider: currentProvider
            },
            2000,
            { ok: false }
          );
        } catch (_error) {
          // Ignore provider save failures in chooser.
        }
        providerTrigger.focus();
        void loadChatsForProvider();
      }

      function setProviderMenuOpen(open) {
        providerMenu.style.display = open ? "grid" : "none";
        providerTrigger.setAttribute("aria-expanded", open ? "true" : "false");
        providerChevron.style.transform = open
          ? "rotate(225deg) translate(-2px, -1px)"
          : "rotate(45deg) translateY(-2px)";
        if (open) {
          const selectedIndex = Math.max(
            providerOptionButtons.findIndex((optionButton) => optionButton.getAttribute("aria-selected") === "true"),
            0
          );
          focusProviderMenuOption(selectedIndex);
        }
      }

      function setProviderMenuValue(providerKey) {
        const normalizedProvider = normalizeProvider(providerKey);
        const selectedOption = PROVIDER_OPTIONS.find((value) => value.key === normalizedProvider);
        providerValue.textContent = selectedOption?.label || "ChatGPT";
        providerOptionButtons.forEach((optionButton) => {
          const selected = optionButton.dataset.value === normalizedProvider;
          optionButton.setAttribute("aria-selected", selected ? "true" : "false");
          optionButton.style.background = selected ? "#edf5ff" : "transparent";
          optionButton.style.color = selected ? "#0a65cc" : "#15171c";
        });
      }

      function focusProviderMenuOption(index) {
        if (!providerOptionButtons.length) {
          return;
        }
        const wrappedIndex = (index + providerOptionButtons.length) % providerOptionButtons.length;
        providerOptionButtons.forEach((optionButton, optionIndex) => {
          const selected = optionButton.getAttribute("aria-selected") === "true";
          optionButton.style.background = optionIndex === wrappedIndex
            ? selected ? "#edf5ff" : "#f7f8fa"
            : selected ? "#edf5ff" : "transparent";
        });
        providerOptionButtons[wrappedIndex].focus();
      }
    });
  }

  function createChooserButton(titleText, subtitleText, tagText) {
    const button = document.createElement("button");
    button.type = "button";
    button.style.textAlign = "left";
    button.style.padding = "11px 12px";
    button.style.border = "1px solid #dfe4eb";
    button.style.borderRadius = "16px";
    button.style.background = "#fff";
    button.style.cursor = "pointer";
    button.style.width = "100%";
    button.style.minWidth = "0";
    button.style.transition = "border-color 120ms ease, box-shadow 120ms ease, background 120ms ease";

    const titleRow = document.createElement("div");
    titleRow.style.display = "flex";
    titleRow.style.alignItems = "center";
    titleRow.style.gap = "8px";
    titleRow.style.minWidth = "0";

    const title = document.createElement("div");
    title.textContent = titleText;
    title.style.fontSize = "12px";
    title.style.fontWeight = "600";
    title.style.minWidth = "0";
    title.style.overflow = "hidden";
    title.style.textOverflow = "ellipsis";
    title.style.whiteSpace = "nowrap";

    titleRow.appendChild(title);

    const cleanTagText = String(tagText || "").replace(/\s+/g, " ").trim();
    if (cleanTagText) {
      const tag = document.createElement("span");
      tag.textContent = cleanTagText;
      tag.style.flex = "0 1 auto";
      tag.style.maxWidth = "48%";
      tag.style.overflow = "hidden";
      tag.style.textOverflow = "ellipsis";
      tag.style.whiteSpace = "nowrap";
      tag.style.border = "1px solid #d7e6f8";
      tag.style.borderRadius = "999px";
      tag.style.background = "#f3f8ff";
      tag.style.color = "#285f9f";
      tag.style.padding = "2px 7px";
      tag.style.fontSize = "10px";
      tag.style.fontWeight = "700";
      titleRow.appendChild(tag);
    }

    button.appendChild(titleRow);

    if (subtitleText) {
      const subtitle = document.createElement("div");
      subtitle.textContent = subtitleText;
      subtitle.style.fontSize = "11px";
      subtitle.style.color = "#666";
      subtitle.style.marginTop = "2px";
      button.appendChild(subtitle);
    }

    return button;
  }

  function setChooserButtonSelected(button, selected) {
    if (!button) {
      return;
    }
    if (selected) {
      button.style.borderColor = "#0a65cc";
      button.style.background = "#edf5ff";
      button.style.boxShadow = "0 0 0 1px rgba(10, 101, 204, 0.18)";
      return;
    }
    button.style.borderColor = "#dfe4eb";
    button.style.background = "#fff";
    button.style.boxShadow = "none";
  }

  function formatChatTitle(chat) {
    const title = String(chat?.title || "").replace(/\s+/g, " ").trim();
    if (title) {
      return title;
    }
    return "Untitled chat";
  }

  function simplifyChatUrl(urlValue) {
    try {
      const parsed = new URL(urlValue);
      return `${parsed.hostname}${parsed.pathname}`;
    } catch (_error) {
      return "";
    }
  }

  function normalizeProvider(value) {
    return PROVIDER_SET.has(value) ? value : "chatgpt";
  }

  function providerLabelFor(providerKey) {
    return PROVIDER_OPTIONS.find((value) => value.key === providerKey)?.label || "ChatGPT";
  }

  async function refreshRouteInfoBox(startMode) {
    if (!routeInfoBox) {
      return;
    }

    if (startMode === "choose") {
      routeInfoBox.textContent = "Destination chooser: you can switch provider in the popup.";
      return;
    }

    const providerResponse = await sendMessageWithTimeout(
      { type: "GET_SELECTED_PROVIDER" },
      2000,
      { ok: false, provider: "chatgpt", providerLabel: "ChatGPT" }
    );
    const providerLabel = String(providerResponse?.providerLabel || providerLabelFor(normalizeProvider(providerResponse?.provider)));
    routeInfoBox.textContent = "Send → your saved ChatGPT chat; reply shown in the gray box";
  }

  async function sendMessageWithTimeout(message, timeoutMs, timeoutFallback) {
    const messagePromise = chrome.runtime.sendMessage(message);
    const timeoutPromise = new Promise((resolve) => {
      setTimeout(() => {
        resolve(timeoutFallback);
      }, timeoutMs);
    });
    return Promise.race([messagePromise, timeoutPromise]);
  }

  function showToast(message) { showAnswerWidget(undefined, "ChatGPT", message); }
  function showTopRightNotice(message) { showAnswerWidget(undefined, "ChatGPT", message); }

  let answerView = null;
  let answerPollTimer;
  function startAnswerPolling() {
    clearInterval(answerPollTimer);
    const started = Date.now();
    answerPollTimer = setInterval(async () => {
      try {
        const state = await chrome.runtime.sendMessage({ type: "GET_ANSWER_STATE" });
        if (state?.updatedAt >= started - 1500) {
          showAnswerWidget(state.answer, "ChatGPT", state.message, state.code);
          if (["ANSWER_READY", "ANSWER_TIMEOUT", "NO_DESTINATION"].includes(state.code)) clearInterval(answerPollTimer);
        }
      } catch (_error) { clearInterval(answerPollTimer); }
      if (Date.now() - started > 310000) clearInterval(answerPollTimer);
    }, 1200);
  }
  function showAnswerWidget(answer, label, status = "Waiting for ChatGPT…", code = "WAITING") {
    if (answerView?.host.isConnected) {
      if (answer !== undefined) answerView.body.textContent = answer || status;
      else if (!answerView.hasAnswer) answerView.body.textContent = status;
      if (answer !== undefined) answerView.hasAnswer = Boolean(answer);
      if (code === "ANSWER_READY") answerView.ready = true;
      if (answer === "") answerView.ready = false;
      answerView.chip.textContent = answerView.ready ? "I" : "C";
      answerView.status.textContent = status;
      answerView.chip.title = status;
      answerView.chip.setAttribute("aria-label", answerView.ready ? "ChatGPT reply ready" : "Waiting for ChatGPT reply");
      return;
    }
    document.getElementById("__snipToAiAnswerWidget")?.remove();
    const host = document.createElement("div");
    host.id = "__snipToAiAnswerWidget";
    host.style.cssText = "all:initial!important;position:fixed!important;right:18px!important;bottom:18px!important;z-index:2147483647!important;display:block!important;";
    const root = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
      * { box-sizing:border-box; } button { cursor:pointer; font:inherit; }
      .chip { color:white;background:#484848;border:1px solid #777;border-radius:5px;padding:0;width:24px;height:24px;box-shadow:0 5px 22px #0005;font:600 13px system-ui; }
      .panel { display:none;width:min(430px,calc(100vw - 36px));background:#e0e0e0;color:#222;border:1px solid #bbb;border-radius:12px;box-shadow:0 8px 30px #0005;font:14px/1.5 system-ui;overflow:hidden; }
      header { display:flex;justify-content:space-between;align-items:center;padding:10px 14px;background:#eee; } header button { border:0;background:transparent;font-size:22px; }
      .status {padding:8px 14px;border-top:1px solid #aaa;font:12px/1.4 system-ui;white-space:pre-wrap;}
      .body { white-space:pre-wrap;overflow-wrap:anywhere;max-height:60vh;overflow:auto;padding:14px;user-select:text; }
    `;
    const chip = document.createElement("button"); chip.className="chip"; chip.type="button";
    chip.textContent=code === "ANSWER_READY" ? "I" : "C"; chip.title=status; chip.setAttribute("aria-label","ChatGPT reply panel");
    const panel=document.createElement("section"); panel.className="panel";
    const header=document.createElement("header");
    const title=document.createElement("strong"); title.textContent="ChatGPT reply · R9";
    const close=document.createElement("button"); close.textContent="×"; close.setAttribute("aria-label","Minimize answer");
    const body=document.createElement("div"); body.className="body"; body.textContent=answer || status;
    const statusLine=document.createElement("div"); statusLine.className="status"; statusLine.textContent=status;
    header.append(title,close); panel.append(header,body,statusLine); root.append(style,chip,panel);
    document.documentElement.appendChild(host);
    chip.onclick=()=>{chip.style.display="none";panel.style.display="block";};
    close.onclick=()=>{panel.style.display="none";chip.style.display="block";};
    answerView={host,body,chip,status:statusLine,hasAnswer:Boolean(answer),ready:code === "ANSWER_READY"};
  }
})();
